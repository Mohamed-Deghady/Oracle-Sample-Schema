set define off
INSERT INTO product_descriptions VALUES(1726-
,'KO'-
,UNISTR(-
'LCD \baa8\b2c8\d130 11/PM'-
),UNISTR(-
'\c561\c815 \d654\ba74 11\c778\ce58 \c218\b3d9 \baa8\b2c8\d130. '||-
'\ace0\d574\c0c1\b3c4\c758 \d3c9\ba74 \d654\ba74\c744 \d1b5'||-
'\d574 \be5b \bc18\c0ac\ac00 \ac10\c18c\b41c \b6f0\c5b4\b09c '||-
'\c774\bbf8\c9c0 \d488\c9c8\c744 \c81c\acf5\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2359-
,'KO'-
,UNISTR(-
'LCD \baa8\b2c8\d130 9/PM'-
),UNISTR(-
'\c561\c815 \d654\ba74 9\c778\ce58 \c218\b3d9 \baa8\b2c8\d130. '||-
'\d06c\ae30\ac00 \c791\c544 \baa8\b2c8\d130 \c8fc\bcc0\c758 '||-
'\c791\c5c5 \c601\c5ed\c744 \bcf4\b2e4 \d6a8\c728\c801\c73c'||-
'\b85c \d65c\c6a9\d560 \c218 \c788\c2b5\b2c8\b2e4. \d50c\b7ec'||-
'\adf8 \c564 \d50c\b808\c774 \d638\d658\c73c\b85c \c27d\ac8c '||-
'\c124\ce58\d560 \c218 \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3060-
,'KO'-
,UNISTR(-
'\baa8\b2c8\d130 17/HR'-
),UNISTR(-
'\ace0\d574\c0c1\b3c4 CRT 17\c778\ce58(\c2e4\d654\ba74 \d06c'||-
'\ae30 16\c778\ce58) \baa8\b2c8\d130. \c774\bbf8\c9c0 \c131\b2a5'||-
'\c774 \b6f0\c5b4\b098\ba70 \c5ec\c720 \c788\b294 \d654\ba74 '||-
'\acf5\ac04\c744 \c81c\acf5\d569\b2c8\b2e4. \c774 \baa8\b2c8'||-
'\d130\b294 \c0c9\c0c1\c744 \b9e4\c6b0 \c120\ba85\d558\ace0 '||-
'\c815\d655\d558\ac8c \d45c\c2dc\d558\ba70 \d654\ba74\c0c1 '||-
'\d45c\c2dc \c81c\c5b4\b97c \d3ec\d568\d55c \cd5c\ace0\c758 '||-
'\ae30\b2a5\c744 \c81c\acf5\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2243-
,'KO'-
,UNISTR(-
'\baa8\b2c8\d130 17/HR/F'-
),UNISTR(-
'\ace0\d574\c0c1\b3c4 17\c778\ce58(\c2e4\d654\ba74 \d06c\ae30 16'||-
'\c778\ce58) \d3c9\ba74 \d654\ba74 \baa8\b2c8\d130. \ace0\ae09 '||-
'\d0c0\c6d0 \bcf4\c815 \c2dc\c2a4\d15c\acfc \d568\aed8 \ace0'||-
'\bc00\b3c4 \ad11\c790 \cd1d\c744 \c0ac\c6a9\d558\c5ec \d654'||-
'\ba74 \baa8\c11c\b9ac \bd80\bd84\c5d0\c11c\b3c4 \cd08\c810'||-
'\c774 \c815\d655\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3057-
,'KO'-
,UNISTR(-
'\baa8\b2c8\d130 17/SD'-
),UNISTR(-
'\b450\aed8\ac00 \c587\c740 17\c778\ce58(\c2e4\d654\ba74 \d06c'||-
'\ae30 16\c778\ce58) CRT \baa8\b2c8\d130. \c774\bbf8\c9c0\ac00 '||-
'\b9e4\c6b0 \ae68\b057\d558\ace0 \c120\ba85\d558\ac8c \d45c'||-
'\d604\b429\b2c8\b2e4. \c804\bb38\c801\c778 \c0c9\c0c1, \ae30'||-
'\c220 \acf5\d559 \bc0f \c2dc\ac01/\c560\b2c8\ba54\c774\c158 '||-
'\c0ac\c6a9\c790\c5d0\ac8c \d544\c694\d55c \c815\d655\d55c '||-
'\c0c9\c0c1\c744 \c81c\acf5\d558\ba70 \b113\c740 \c791\c5c5 '||-
'\c601\c5ed\c73c\b85c \c0dd\c0b0\c131\c744 \b192\c77c \c218 '||-
'\c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3061-
,'KO'-
,UNISTR(-
'\baa8\b2c8\d130 19/SD'-
),UNISTR(-
'\b450\aed8\ac00 \c587\c740 19\c778\ce58(\c2e4\d654\ba74 \d06c'||-
'\ae30 18\c778\ce58) CRT \baa8\b2c8\d130. \ace0\b300\be44 \ac80'||-
'\c815 \d654\ba74 \cf54\d305\c73c\b85c \b6f0\c5b4\b09c \b300'||-
'\be44 \bc0f \ba85\c554 \b2e8\acc4 \c131\b2a5\c744 \c81c\acf5'||-
'\d569\b2c8\b2e4. \b3d9\c801 \c800\c74c \bc18\c751\c774 \ac00'||-
'\b2a5\d558\b3c4\b85d \c0c8\b85c \c124\acc4\b41c \c804\bb38 '||-
'\c99d\d3ed \c2a4\d53c\cee4\b97c \d1b5\d574 \baa8\b4e0 \ba40'||-
'\d2f0\bbf8\b514\c5b4 \c624\b514\c624\c5d0\c11c \c0dd\c0dd\d55c'||-
' \c18c\b9ac\c640 \ae4a\ace0 \d48d\bd80\d55c \c800\c74c\c744 '||-
'\acbd\d5d8\d560 \c218 \c788\c2b5\b2c8\b2e4. \b610\d55c \c0c9'||-
'\c0c1\c73c\b85c \ad6c\bd84\b41c \cf00\c774\be14\acfc \ac04'||-
'\d3b8\d55c \d50c\b7ec\adf8 \c564 \d50c\b808\c774 \c124\ce58 '||-
'\bc0f \d654\ba74\c0c1\c758 \b514\c9c0\d138 \c81c\c5b4\b97c '||-
'\c0ac\c6a9\d558\c5ec \b2e8\c2dc\ac04\c5d0 \d6cc\b96d\d55c '||-
'\ba40\d2f0\bbf8\b514\c5b4\c640 \c778\d130\b137 \d658\acbd\c744'||-
' \c870\c131\d560 \c218 \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2245-
,'KO'-
,UNISTR(-
'\baa8\b2c8\d130 19/SD/M'-
),UNISTR(-
'\b450\aed8\ac00 \c587\c740 19\c778\ce58(\c2e4\d654\ba74 \d06c'||-
'\ae30 18\c778\ce58) \d751\bc31 \baa8\b2c8\d130. \acbd\c81c\c801'||-
'\c778 \c124\acc4\b85c \b6f0\c5b4\b09c \c774\bbf8\c9c0 \c131'||-
'\b2a5\c744 \c81c\acf5\d569\b2c8\b2e4. \ac04\d3b8\d55c \d654'||-
'\ba74\c0c1 \d45c\c2dc \ba54\b274\b97c \c0ac\c6a9\d558\c5ec '||-
'\d654\ba74 \d06c\ae30, \c0c9\c0c1 \bc0f \c774\bbf8\c9c0 \c18d'||-
'\c131\c744 \c27d\ac8c \c870\c815\d560 \c218 \c788\c2b5\b2c8'||-
'\b2e4. \baa8\b2c8\d130\b97c PC\c5d0 \c5f0\acb0\b9cc \d558\ba74 '||-
'\bc14\b85c \c0ac\c6a9\d560 \c218 \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3065-
,'KO'-
,UNISTR(-
'\baa8\b2c8\d130 21/D'-
),UNISTR(-
'21\c778\ce58(\c2e4\d654\ba74 \d06c\ae30 20\c778\ce58) CRT \baa8'||-
'\b2c8\d130. Digital OptiScan \ae30\c220\c744 \d1b5\d574 75Hz\c5d0'||-
'\c11c 1600 x 1200\c758 \d574\c0c1\b3c4\b97c \c81c\acf5\d569\b2c8'||-
'\b2e4. \d06c\ae30(\b192\c774x\b108\be44x\b450\aed8): 8.3 x 18.5 x'||-
' 15\c778\ce58. \bd84\b9ac\ac00 \ac00\b2a5\d558\ba70 \baa8\b2c8'||-
'\d130 \c804\c6d0\c744 \c0ac\c6a9\d558\b294 Platinum Series \c2a4'||-
'\d53c\cee4\b294 \c0dd\c0dd\d55c \c74c\d5a5\acfc \d3b8\b9ac'||-
'\d55c \b514\c9c0\d138 \c624\b514\c624 \d50c\b808\c774\c5b4 '||-
'\c7ad\c744 \c81c\acf5\d569\b2c8\b2e4. \b514\c9c0\d138 \c624'||-
'\b514\c624 \d50c\b808\c774\c5b4\b97c \c5f0\acb0\b9cc \d558'||-
'\ba74 PC \c804\c6d0\c744 \cf1c\c9c0 \c54a\c740 \cc44 \b4e4\c744'||-
' \c218 \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3331-
,'KO'-
,UNISTR(-
'\baa8\b2c8\d130 21/HR'-
),UNISTR(-
'\ace0\d574\c0c1\b3c4 21\c778\ce58(\c2e4\d654\ba74 \d06c\ae30 20'||-
'\c778\ce58) \baa8\b2c8\d130. \c774 \baa8\b2c8\d130\b294 \c5c5'||-
'\bb34, \c804\c790 \cd9c\d310 \bc0f \adf8\b798\d53d \c751\c6a9 '||-
'\d504\b85c\adf8\b7a8\c5d0 \c801\d569\d569\b2c8\b2e4. \c751'||-
'\c6a9 \d504\b85c\adf8\b7a8 \c2e4\d589\c5d0 \d544\c694\d55c '||-
'\c791\c5c5 \c601\c5ed\c744 \bcf4\b2e4 \b9ce\c774 \d655\bcf4'||-
'\d558\c5ec \c791\c5c5 \c0dd\c0b0\c131\c774 \b192\c2b5\b2c8'||-
'\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2252-
,'KO'-
,UNISTR(-
'\baa8\b2c8\d130 21/HR/M'-
),UNISTR(-
'\ace0\d574\c0c1\b3c4 21\c778\ce58(\c2e4\d654\ba74 \d06c\ae30 20'||-
'\c778\ce58) \d751\bc31 \baa8\b2c8\d130. \b2e8\c704 \d06c\ae30: '||-
'35.6 x 29.6 x 33.3cm(14.6kg), \d328\d0a4\c9c0: 40.53 x 31.24 x 35.39cm('||-
'16.5kg). \c218\d3c9 \c8fc\d30c\c218: 31.5 - 54kHz, \c218\c9c1 '||-
'\c8fc\d30c\c218: 50 - 120Hz. \bc94\c6a9 \c804\c6d0 \acf5\ae09'||-
'\ae30: 90 - 132V, 50 - 60Hz.'-
));
INSERT INTO product_descriptions VALUES(3064-
,'KO'-
,UNISTR(-
'\baa8\b2c8\d130 21/SD'-
),UNISTR(-
'\b450\aed8\ac00 \c587\c740 21\c778\ce58(\c2e4\d654\ba74 \d06c'||-
'\ae30 20\c778\ce58) \baa8\b2c8\d130. 0.25-0.28 Aperture Grille Pitch'||-
', 76Hz\c5d0\c11c \d574\c0c1\b3c4 1920 x 1200\ae4c\c9c0 \c9c0\c6d0'||-
'\d558\ba70, \d654\ba74\c0c1 \d45c\c2dc \bc0f \c804\b3c4\c2dd '||-
'\bc18\c0ac \bc29\c9c0 \d544\b984 \cf54\d305 \b4f1\c758 \d2b9'||-
'\c9d5\c774 \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3155-
,'KO'-
,UNISTR(-
'\baa8\b2c8\d130 \ac78\c774 - HD'-
),UNISTR(-
'\ac15\b825 \baa8\b2c8\d130 \ac78\c774, \cd5c\b300 \baa8\b2c8'||-
'\d130 \bb34\ac8c 30kg'-
));
INSERT INTO product_descriptions VALUES(3234-
,'KO'-
,UNISTR(-
'\baa8\b2c8\d130 \ac78\c774 - STD'-
),UNISTR(-
'\d45c\c900 \baa8\b2c8\d130 \ac78\c774, \cd5c\b300 \baa8\b2c8'||-
'\d130 \bb34\ac8c 10kg'-
));
INSERT INTO product_descriptions VALUES(3350-
,'KO'-
,UNISTR(-
'\d50c\b77c\c988\b9c8 \baa8\b2c8\d130 10/LE/VGA'-
),UNISTR(-
'10\c778\ce58 \c800\c804\b825 \d50c\b77c\c988\b9c8 \baa8\b2c8'||-
'\d130, VGA \d574\c0c1\b3c4'-
));
INSERT INTO product_descriptions VALUES(2236-
,'KO'-
,UNISTR(-
'\d50c\b77c\c988\b9c8 \baa8\b2c8\d130 10/TFT/XGA'-
),UNISTR(-
'\b7a9\d1b1 \cef4\d4e8\d130\c6a9 10\c778\ce58 TFT XGA \d3c9\ba74 '||-
'\d654\ba74 \baa8\b2c8\d130'-
));
INSERT INTO product_descriptions VALUES(3054-
,'KO'-
,UNISTR(-
'\d50c\b77c\c988\b9c8 \baa8\b2c8\d130 10/XGA'-
),UNISTR(-
'10\c778\ce58 \d45c\c900 \d50c\b77c\c988\b9c8 \baa8\b2c8\d130, X'||-
'GA \d574\c0c1\b3c4. \d3c9\ba74\c758 \ace0\d574\c0c1\b3c4 \d654'||-
'\ba74\c774 \be5b \bc18\c0ac\ac00 \ac10\c18c\b41c \b6f0\c5b4'||-
'\b09c \c774\bbf8\c9c0 \d488\c9c8\c744 \c81c\acf5\d569\b2c8'||-
'\b2e4.'-
));
INSERT INTO product_descriptions VALUES(1782-
,'KO'-
,UNISTR(-
'Compact 400/DQ'-
),UNISTR(-
'\cd08\b2f9 400\c790\b97c \c778\c1c4\d560 \c218 \c788\b294 \ace0'||-
'\c18d \b4dc\b798\d504\d2b8 \d504\b9b0\d130. \d06c\ae30(\b192'||-
'\c774x\b108\be44x\b450\aed8): 17.34 x 24.26 x 26.32\c778\ce58. '||-
'\c778\d130\d398\c774\c2a4: RS-232 \c9c1\b82c(9\d540), \d655\c7a5'||-
' \c2ac\b86f \c5c6\c74c. \c6a9\c9c0 \d06c\ae30: A4, US Letter.'-
));
INSERT INTO product_descriptions VALUES(2430-
,'KO'-
,UNISTR(-
'Compact 400/LQ'-
),UNISTR(-
'\cd08\b2f9 400\c790\b97c \c778\c1c4\d560 \c218 \c788\b294 \ace0'||-
'\c18d \ace0\d488\c9c8 \d504\b9b0\d130. \d06c\ae30(\b192\c774x'||-
'\b108\be44x\b450\aed8): 12.37 x 27.96 x 23.92\c778\ce58. \c778'||-
'\d130\d398\c774\c2a4: RS-232 \c9c1\b82c(25\d540), \d655\c7a5 '||-
'\c2ac\b86f 3\ac1c. \c6a9\c9c0 \d06c\ae30: A2, A3, A4.'-
));
INSERT INTO product_descriptions VALUES(1792-
,'KO'-
,UNISTR(-
'Industrial 600/DQ'-
),UNISTR(-
'\cd08\b2f9 600\c790\b97c \c778\c1c4\d560 \c218 \c788\b294 \c640'||-
'\c774\b4dc \ce90\b9ac\c9c0 \ceec\b7ec \ae30\b2a5\c758 \ace0'||-
'\c18d \b4dc\b798\d504\d2b8 \d504\b9b0\d130. \d06c\ae30(\b192'||-
'\c774x\b108\be44x\b450\aed8): 22.31 x 25.73 x 20.12\c778\ce58. '||-
'\c6a9\c9c0 \d06c\ae30: 3x5\c778\ce58~11x17\c778\ce58 \c804\ccb4 '||-
'\c601\c5ed \d655\c7a5 \c778\c1c4 \ac00\b2a5.'-
));
INSERT INTO product_descriptions VALUES(1791-
,'KO'-
,UNISTR(-
'Industrial 700/HD'-
),UNISTR(-
'\cd08\b2f9 700\c790 \c778\c1c4 \ac00\b2a5, \c678\c7a5\c774 '||-
'\d2bc\d2bc\d558\ace0 \ba3c\c9c0 \bc29\c9c0 \ae30\b2a5\c774 '||-
'\c788\b294 \c0b0\c5c5\c6a9 \b3c4\d2b8 \b9e4\d2b8\b9ad\c2a4 '||-
'\d504\b9b0\d130. \c778\d130\d398\c774\c2a4: \c13c\d2b8\b85c'||-
'\b2c9\c2a4 \bcd1\b82c IEEE 1284 \d638\d658. \c6a9\c9c0 \d06c'||-
'\ae30: 3x5\c778\ce58~11x17\c778\ce58 \c804\ccb4 \c601\c5ed \d655'||-
'\c7a5 \c778\c1c4 \ac00\b2a5. \ba54\baa8\b9ac: 4MB. \d06c\ae30('||-
'\b192\c774x\b108\be44x\b450\aed8): 9.3 x 16.5 x 13\c778\ce58.'-
));
INSERT INTO product_descriptions VALUES(2302-
,'KO'-
,UNISTR(-
'Inkjet B/6'-
),UNISTR(-
'\c789\d06c\c82f \d504\b9b0\d130, \d751\bc31, \bd84\b2f9 6\d398'||-
'\c774\c9c0 \c778\c1c4, \d574\c0c1\b3c4 600x300dpi. \c778\d130'||-
'\d398\c774\c2a4: \c13c\d2b8\b85c\b2c9\c2a4 \bcd1\b82c, IEEE 1284'||-
' \d638\d658. \d06c\ae30(\b192\c774x\b108\be44x\b450\aed8): 7.3 x'||-
' 17.5 x 14\c778\ce58. \c6a9\c9c0 \d06c\ae30: A3, A4, US legal. '||-
'\d655\c7a5 \c2ac\b86f \c5c6\c74c.'-
));
INSERT INTO product_descriptions VALUES(2453-
,'KO'-
,UNISTR(-
'Inkjet C/4'-
),UNISTR(-
'\c789\d06c\c82f \d504\b9b0\d130, \ceec\b7ec(\bcc4\b3c4\c758 '||-
'\c789\d06c \ce74\d2b8\b9ac\c9c0 2\ac1c), \bd84\b2f9 6\d398\c774'||-
'\c9c0 \c778\c1c4(\d751\bc31), \bd84\b2f9 4\d398\c774\c9c0 \c778'||-
'\c1c4(\ceec\b7ec), \d574\c0c1\b3c4 600x300dpi. \c778\d130\d398'||-
'\c774\c2a4: \bc14\c774\c624\b514\b809\c154\b110 IEEE 1284 \d638'||-
'\d658 \bcd1\b82c \c778\d130\d398\c774\c2a4 \bc0f RS-232 \c9c1'||-
'\b82c(9\d540) \c778\d130\d398\c774\c2a4 \ac1c\bc29\d615 EIO '||-
'\d655\c7a5 \c2ac\b86f 2\ac1c. \ba54\baa8\b9ac: 8MB 96KB \c218'||-
'\c2e0\c790 \bc84\d37c.'-
));
INSERT INTO product_descriptions VALUES(1797-
,'KO'-
,UNISTR(-
'Inkjet C/8/HQ'-
),UNISTR(-
'\c789\d06c\c82f \d504\b9b0\d130, \ceec\b7ec, \bd84\b2f9 8\d398'||-
'\c774\c9c0 \c778\c1c4, \ace0\d574\c0c1\b3c4(\c0ac\c9c4 \d488'||-
'\c9c8). \ba54\baa8\b9ac: 16MB. \d06c\ae30(\b192\c774x\b108\be44x'||-
'\b450\aed8): 7.3 x 17.5 x 14\c778\ce58. \c6a9\c9c0 \d06c\ae30: A4,'||-
' US Letter, envelopes. \c778\d130\d398\c774\c2a4: \c13c\d2b8\b85c'||-
'\b2c9\c2a4 \bcd1\b82c, IEEE 1284 \d638\d658.'-
));
INSERT INTO product_descriptions VALUES(2459-
,'KO'-
,UNISTR(-
'LaserPro 1200/8/BW'-
),UNISTR(-
'\c804\bb38 \d751\bc31 \b808\c774\c800 \d504\b9b0\d130, \d574'||-
'\c0c1\b3c4 1200dpi, \cd08\b2f9 8\d398\c774\c9c0 \c778\c1c4. '||-
'\d06c\ae30(\b192\c774x\b108\be44x\b450\aed8): 22.37 x 19.86 x 21.9'||-
'2\c778\ce58. \c18c\d504\d2b8\c6e8\c5b4: SPNIX v4.0\c5d0 \b300'||-
'\d55c \ace0\ae09 \b4dc\b77c\c774\bc84 \c9c0\c6d0; MS-DOS \b0b4'||-
'\c7a5 \d504\b9b0\d130 \b4dc\b77c\c774\bc84: ZoomSmart \d06c\ae30'||-
' \c870\c815 \ae30\c220, \b098\b220\cc0d\ae30, \baa8\c544\cc0d'||-
'\ae30, \ac70\c6b8 \d6a8\acfc, \c218\c704 \d45c\c2dc, \bbf8\b9ac'||-
'\bcf4\ae30, \be60\b978 \c124\c815, \b808\c774\c800 \d504\b9b0'||-
'\d130 \c5ec\bc31 \c81c\ac70.'-
));
INSERT INTO product_descriptions VALUES(3127-
,'KO'-
,UNISTR(-
'LaserPro 600/6/BW'-
),UNISTR(-
'\d45c\c900 \d751\bc31 \b808\c774\c800 \d504\b9b0\d130, \d574'||-
'\c0c1\b3c4 600dpi, \cd08\b2f9 6\d398\c774\c9c0 \c778\c1c4. \c778'||-
'\d130\d398\c774\c2a4: \c13c\d2b8\b85c\b2c9\c2a4 \bcd1\b82c, IEE'||-
'E 1284 \d638\d658. \ba54\baa8\b9ac: 8MB 96KB \c218\c2e0\c790 '||-
'\bc84\d37c. SPNIX AutoCAM v.17 \d638\d658 \b4dc\b77c\c774\bc84'||-
'\c6a9 MS-DOS ToolBox \c720\d2f8\b9ac\d2f0.'-
));
INSERT INTO product_descriptions VALUES(2254-
,'KO'-
,UNISTR(-
'HD 10GB /I'-
),UNISTR(-
'10GB \c6a9\b7c9 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774\be0c'||-
'(\b0b4\bd80). \c774\b7ec\d55c \b4dc\b77c\c774\be0c\b294 \d604'||-
'\c7ac \cd94\c138\c778 \b370\c774\d130 \c911\c2ec\c758 \ae30'||-
'\c5c5 \d658\acbd \c694\ad6c\c5d0 \b9de\ac8c \c124\acc4\b418'||-
'\c5c8\c73c\ba70 RAID \c751\c6a9 \d504\b85c\adf8\b7a8\c5d0 \c774'||-
'\c0c1\c801\c785\b2c8\b2e4. \bc94\c6a9 \c635\c158 \d0a4\d2b8'||-
'\b294 \d1b5\d569 \c11c\bc84\b098 \c800\c7a5 \c601\c5ed \c2dc'||-
'\c2a4\d15c\c5d0 \c989\c2dc \c124\ce58\d560 \c218 \c788\b3c4'||-
'\b85d \d574\b2f9 \d56b \d50c\b7ec\adf8 \d2b8\b808\c774\c5d0 '||-
'\ad6c\c131\b418\ace0 \bbf8\b9ac \b9c8\c6b4\d2b8\b429\b2c8\b2e4'||-
'.'-
));
INSERT INTO product_descriptions VALUES(3353-
,'KO'-
,UNISTR(-
'HD 10GB /R'-
),UNISTR(-
'10GB \c774\b3d9\c2dd \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774'||-
'\be0c. Supra7 \b514\c2a4\d06c \b4dc\b77c\c774\be0c\b294 \cd5c'||-
'\c2e0 \ae30\c220\c744 \c81c\acf5\d558\c5ec \ae30\c5c5 \c131'||-
'\b2a5\c744 \d5a5\c0c1\c2dc\d0a4\ace0 \cd5c\ace0 160MB/s\c758 '||-
'\c804\c1a1 \c18d\b3c4\b97c \c9c0\c6d0\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3069-
,'KO'-
,UNISTR(-
'HD 10GB /S'-
),UNISTR(-
'\d45c\c900 \b9c8\c6b4\d2b8\b97c \c704\d55c 10GB \d558\b4dc '||-
'\b514\c2a4\d06c \b4dc\b77c\c774\be0c. Supra5 \c2dc\c2a4\d15c'||-
'\acfc \d638\d658\b418\ba70 \c0ac\c6a9\c790\b294 \c99d\ac00'||-
'\b41c \c800\c7a5 \c601\c5ed \c6a9\b7c9\c744 \be60\b974\ac8c '||-
'\c81c\acf5\d558\ae30 \c704\d574 \c774\b7ec\d55c \b4dc\b77c'||-
'\c774\be0c\b97c \bc30\ce58\d558\ac70\b098 \c7ac\bc30\ce58\d560'||-
' \c218 \c788\c2b5\b2c8\b2e4. Supra \b4dc\b77c\c774\be0c\b294 '||-
'\d38c\c6e8\c5b4 \be44\d638\d658\c131\c758 \c704\d5d8\c744 '||-
'\bc30\c81c\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2253-
,'KO'-
,UNISTR(-
'HD 10GB @5400 /SE'-
),UNISTR(-
'10GB \c6a9\b7c9 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774\be0c'||-
'(\c678\bd80) SCSI \c778\d130\d398\c774\c2a4, 5400RPM. \bc94\c6a9 '||-
'\c635\c158 \d0a4\d2b8\b294 \d1b5\d569 \c11c\bc84\b098 \c800'||-
'\c7a5 \c601\c5ed \c2dc\c2a4\d15c\c5d0 \c989\c2dc \c124\ce58'||-
'\d560 \c218 \c788\b3c4\b85d \d574\b2f9 \d56b \d50c\b7ec\adf8 '||-
'\d2b8\b808\c774\c5d0 \ad6c\c131\b418\ace0 \bbf8\b9ac \b9c8'||-
'\c6b4\d2b8\b429\b2c8\b2e4. Supra \b4dc\b77c\c774\be0c\b294 '||-
'\d38c\c6e8\c5b4 \be44\d638\d658\c131\c758 \c704\d5d8\c744 '||-
'\bc30\c81c\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3354-
,'KO'-
,UNISTR(-
'HD 12GB /I'-
),UNISTR(-
'12GB \c6a9\b7c9 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774\be0c'||-
'(\b0b4\bd80). Supra \b4dc\b77c\c774\be0c\b294 \d38c\c6e8\c5b4 '||-
'\be44\d638\d658\c131\c758 \c704\d5d8\c744 \bc30\c81c\d569\b2c8'||-
'\b2e4. \c5ed\d638\d658\c131: \cd5c\c801\d654\b41c \c194\b8e8'||-
'\c158 \bc0f \c774\d6c4\c758 \c131\c7a5\c744 \c704\d574 Supra2'||-
'\c640 Supra3 \c7a5\ce58\b97c \d63c\d569\d558\ac70\b098 \b300'||-
'\c751\c2dc\d0ac \c218 \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3072-
,'KO'-
,UNISTR(-
'HD 12GB /N'-
),UNISTR(-
'\d611\c758 \b9c8\c6b4\d2b8\b97c \c704\d55c 12GB \d558\b4dc '||-
'\b514\c2a4\d06c \b4dc\b77c\c774\be0c. Supra9 \d56b \d50c\b7ec'||-
'\adf8 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774\be0c\b294 '||-
'\b4dc\b77c\c774\be0c\b97c \c628\b77c\c778\c73c\b85c \c124\ce58'||-
' \b610\b294 \c81c\ac70\d560 \c218 \c788\b294 \ae30\b2a5\c744 '||-
'\c81c\acf5\d569\b2c8\b2e4. \bcf8\c0ac\c758 \d56b \d50c\b7ec'||-
'\adf8 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774\be0c\b294 '||-
'\c2e0\b8b0\c131\acfc \c131\b2a5\c5d0 \b300\d55c \c5c4\aca9'||-
'\d55c \d45c\c900\c744 \c900\c218\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3334-
,'KO'-
,UNISTR(-
'HD 12GB /R'-
),UNISTR(-
'12GB \c774\b3d9\c2dd \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774'||-
'\be0c. \b2e4\c591\d55c \ae30\c5c5 \d50c\b7ab\d3fc\acfc \d638'||-
'\d658\b418\bbc0\b85c \c99d\ac00\b41c \c800\c7a5 \c601\c5ed '||-
'\c6a9\b7c9\c744 \be60\b974\ac8c \c81c\acf5\d558\ae30 \c704'||-
'\d574 \c774 \b4dc\b77c\c774\be0c\b97c \bc30\ce58 \bc0f \c7ac'||-
'\bc30\ce58\d560 \c218 \c788\c2b5\b2c8\b2e4. Supra7 \bc94\c6a9 '||-
'\b514\c2a4\d06c \b4dc\b77c\c774\be0c\b294 \d68c\c0ac \c11c'||-
'\bc84 \bc0f \c678\bd80 \c800\c7a5 \c601\c5ed \c7a5\ce58\c5d0'||-
'\c11c \d638\d658\b418\b294 \cc28\c138\b300 \ace0\c131\b2a5 '||-
'\d56b \d50c\b7ec\adf8 \b4dc\b77c\c774\bc84\c785\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3071-
,'KO'-
,UNISTR(-
'HD 12GB /S'-
),UNISTR(-
'\d45c\c900 \b9c8\c6b4\d2b8\b97c \c704\d55c 12GB \d558\b4dc '||-
'\b514\c2a4\d06c \b4dc\b77c\c774\be0c. Supra9 \d56b \d50c\b7ec'||-
'\adf8 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774\be0c\b294 '||-
'\b4dc\b77c\c774\be0c\b97c \c628\b77c\c778\c73c\b85c \c124\ce58'||-
' \b610\b294 \c81c\ac70\d560 \c218 \c788\b294 \ae30\b2a5\c744 '||-
'\c81c\acf5\d569\b2c8\b2e4. \bcf8\c0ac\c758 \d56b \d50c\b7ec'||-
'\adf8 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774\be0c\b294 '||-
'\c2e0\b8b0\c131\acfc \c131\b2a5\c5d0 \b300\d55c \c5c4\aca9'||-
'\d55c \d45c\c900\c744 \c900\c218\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2255-
,'KO'-
,UNISTR(-
'HD 12GB @7200 /SE'-
),UNISTR(-
'12GB \c6a9\b7c9 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774\be0c'||-
'(\c678\bd80) SCSI, 7200RPM. \c774\b7ec\d55c \b4dc\b77c\c774\be0c'||-
'\b294 \d604\c7ac \cd94\c138\c778 \b370\c774\d130 \c911\c2ec'||-
'\c758 \ae30\c5c5 \d658\acbd \c694\ad6c\c5d0 \b9de\ac8c \c124'||-
'\acc4\b418\c5c8\c73c\ba70 RAID \c751\c6a9 \d504\b85c\adf8\b7a8'||-
'\c5d0 \c0ac\c6a9\d560 \c218 \c788\c2b5\b2c8\b2e4. \bc94\c6a9 '||-
'\c635\c158 \d0a4\d2b8\b294 \d1b5\d569 \c11c\bc84\b098 \c800'||-
'\c7a5 \c601\c5ed \c2dc\c2a4\d15c\c5d0 \c989\c2dc \c124\ce58'||-
'\d560 \c218 \c788\b3c4\b85d \d574\b2f9 \d56b \d50c\b7ec\adf8 '||-
'\d2b8\b808\c774\c5d0 \ad6c\c131\b418\ace0 \bbf8\b9ac \b9c8'||-
'\c6b4\d2b8\b429\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(1743-
,'KO'-
,UNISTR(-
'HD 18.2GB @10000 /E'-
),UNISTR(-
'\c678\bd80 \d558\b4dc \b4dc\b77c\c774\be0c \b514\c2a4\d06c - 18'||-
'.2GB, 10,000RPM. \c774\b7ec\d55c \b4dc\b77c\c774\be0c\b294 \d604'||-
'\c7ac \cd94\c138\c778 \b370\c774\d130 \c911\c2ec\c758 \ae30'||-
'\c5c5 \d658\acbd\c758 \c694\ad6c\c5d0 \b9de\ac8c \c124\acc4'||-
'\b418\c5c8\c73c\ba70 RAID \c751\c6a9 \d504\b85c\adf8\b7a8\c5d0 '||-
'\c774\c0c1\c801\c785\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2382-
,'KO'-
,UNISTR(-
'HD 18.2GB@10000 /I'-
),UNISTR(-
'18.2GB SCSI \d558\b4dc \b514\c2a4\d06c @ 10000RPM(\b0b4\bd80). Supr'||-
'a7 \bc94\c6a9 \b514\c2a4\d06c \b4dc\b77c\c774\be0c\b294 \b2e4'||-
'\c591\d55c \ae30\c5c5 \d50c\b7ab\d3fc\acfc\c758 \b4dc\b77c'||-
'\c774\be0c \d638\d658\c131\c744 \d1b5\d574 \ace0\ac1d\c5d0'||-
'\ac8c \cd5c\ace0\c758 \d22c\c790 \bcf4\c7a5 \bc0f \b2e8\c21c'||-
'\d654\b97c \c81c\acf5\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3399-
,'KO'-
,UNISTR(-
'HD 18GB /SE'-
),UNISTR(-
'18GB SCSI \c678\bd80 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774'||-
'\be0c. Supra5 \bc94\c6a9 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c'||-
'\c774\be0c\b294 \b2e4\c591\d55c \c11c\bc84, RAID \bc30\c5f4 '||-
'\bc0f \c678\bd80 \c800\c7a5 \c601\c5ed \c7a5\ce58 \ac04\c5d0 '||-
'\d56b \d50c\b7ec\adf8 \ae30\b2a5\c744 \c81c\acf5\d569\b2c8'||-
'\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3073-
,'KO'-
,UNISTR(-
'HD 6GB /I'-
),UNISTR(-
'6GB \c6a9\b7c9 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774\be0c('||-
'\b0b4\bd80). Supra \b4dc\b77c\c774\be0c\b294 \d38c\c6e8\c5b4 '||-
'\be44\d638\d658\c131\c758 \c704\d5d8\c744 \bc30\c81c\d569\b2c8'||-
'\b2e4.'-
));
INSERT INTO product_descriptions VALUES(1768-
,'KO'-
,UNISTR(-
'HD 8.2GB @5400'-
),UNISTR(-
'\d558\b4dc \b4dc\b77c\c774\be0c \b514\c2a4\d06c - 8.2GB, 5,400RPM'||-
'. Supra \b4dc\b77c\c774\be0c\b294 \d38c\c6e8\c5b4 \be44\d638'||-
'\d658\c131\c758 \c704\d5d8\c744 \bc30\c81c\d569\b2c8\b2e4. '||-
'\d45c\c900 \c9c1\b82c RS-232 \c778\d130\d398\c774\c2a4\c785'||-
'\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2410-
,'KO'-
,UNISTR(-
'HD 8.4GB @5400'-
),UNISTR(-
'8.4GB \d558\b4dc \b514\c2a4\d06c @ 5400RPM. \c18c\c720 \be44\c6a9'||-
' \ac10\c18c: \ae30\c5c5 \d50c\b7ab\d3fc\c5d0 \b4dc\b77c\c774'||-
'\be0c\b97c \d65c\c6a9\d560 \c218 \c788\c2b5\b2c8\b2e4. \c774 '||-
'\d56b \d50c\b7ec\adf8 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c'||-
'\c774\be0c\b294 \c2e0\b8b0\c131\acfc \c131\b2a5\c5d0 \b300'||-
'\d55c \c5c4\aca9\d55c \d45c\c900\c744 \c900\c218\d569\b2c8'||-
'\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2257-
,'KO'-
,UNISTR(-
'HD 8GB /I'-
),UNISTR(-
'8GB \c6a9\b7c9 \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774\be0c('||-
'\b0b4\bd80). Supra9 \d56b \d50c\b7ec\adf8 \d558\b4dc \b514\c2a4'||-
'\d06c \b4dc\b77c\c774\be0c\b294 \b4dc\b77c\c774\be0c\b97c '||-
'\c628\b77c\c778\c73c\b85c \c124\ce58 \b610\b294 \c81c\ac70'||-
'\d560 \c218 \c788\b294 \ae30\b2a5\c744 \c81c\acf5\d569\b2c8'||-
'\b2e4. \c5ed\d638\d658\c131: \cd5c\c801\d654\b41c \c194\b8e8'||-
'\c158 \bc0f \c774\d6c4\c758 \c131\c7a5\c744 \c704\d574 Supra2'||-
'\c640 Supra3 \c7a5\ce58\b97c \d63c\d569\d560 \c218 \c788\c2b5'||-
'\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3400-
,'KO'-
,UNISTR(-
'HD 8GB /SE'-
),UNISTR(-
'8GB \c6a9\b7c9 SCSI \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774'||-
'\be0c(\c678\bd80). Supra7 \b514\c2a4\d06c \b4dc\b77c\c774\be0c'||-
'\b294 \cd5c\c2e0 \ae30\c220\c744 \c81c\acf5\d558\c5ec \ae30'||-
'\c5c5 \c131\b2a5\c744 \d5a5\c0c1\c2dc\d0a4\ace0 \cd5c\ace0 255M'||-
'B/\cd08\ae4c\c9c0\c758 \c804\c1a1 \c18d\b3c4\b97c \c9c0\c6d0'||-
'\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3355-
,'KO'-
,UNISTR(-
'HD 8GB /SI'-
),UNISTR(-
'8GB SCSI \d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774\be0c(\b0b4'||-
'\bd80). \b2e4\c591\d55c \ae30\c5c5 \d50c\b7ab\d3fc\acfc \d638'||-
'\d658\b418\bbc0\b85c \c99d\ac00\b41c \c800\c7a5 \c601\c5ed '||-
'\c6a9\b7c9\c744 \be60\b974\ac8c \c81c\acf5\d558\ae30 \c704'||-
'\d574 \c774 \b4dc\b77c\c774\be0c\b97c \bc30\ce58 \bc0f \c7ac'||-
'\bc30\ce58\d560 \c218 \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(1772-
,'KO'-
,UNISTR(-
'HD 9.1GB @10000'-
),UNISTR(-
'\d558\b4dc \b514\c2a4\d06c \b4dc\b77c\c774\be0c - 9.1GB, 10,000RP'||-
'M. \c774\b7ec\d55c \b4dc\b77c\c774\be0c\b294 \b370\c774\d130 '||-
'\c911\c2ec\c758 \ae30\c5c5 \d658\acbd\c5d0 \b9de\ac8c \c124'||-
'\acc4\b418\c5c8\c2b5\b2c8\b2e4. \c190\c26c\c6b4 \c5c5\bb34 '||-
'\c218\d589: \bc30\ce58\d560 \c751\c6a9 \d504\b85c\adf8\b7a8'||-
'\c5d0 \ad00\acc4\c5c6\c774 \d544\c694\d55c \b4dc\b77c\c774'||-
'\be0c\b97c \c27d\ac8c \c120\d0dd\d560 \c218 \c788\c2b5\b2c8'||-
'\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2414-
,'KO'-
,UNISTR(-
'HD 9.1GB @10000 /I'-
),UNISTR(-
'9.1GB SCSI \d558\b4dc \b514\c2a4\d06c @ 10000RPM(\b0b4\bd80). Supra'||-
'7 \b514\c2a4\d06c \b4dc\b77c\c774\be0c\b294 10,000RPM \cd95 '||-
'\c18d\b3c4\c640 18GB \bc0f 9.1GB \c6a9\b7c9\c5d0\c11c \c0ac\c6a9'||-
'\d560 \c218 \c788\c2b5\b2c8\b2e4. SCSI \bc0f RS-232 \c778\d130'||-
'\d398\c774\c2a4\c785\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2415-
,'KO'-
,UNISTR(-
'HD 9.1GB @7200'-
),UNISTR(-
'9.1GB \d558\b4dc \b514\c2a4\d06c @ 7200RPM. \bc94\c6a9 \c635\c158'||-
' \d0a4\d2b8\b294 \d1b5\d569 \c11c\bc84\b098 \c800\c7a5 \c601'||-
'\c5ed \c2dc\c2a4\d15c\c5d0 \be60\b974\ac8c \c124\ce58\d560 '||-
'\c218 \c788\b3c4\b85d \d574\b2f9 \d56b \d50c\b7ec\adf8 \d2b8'||-
'\b808\c774\c5d0 \ad6c\c131\b418\ace0 \bbf8\b9ac \b9c8\c6b4'||-
'\d2b8\b429\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2395-
,'KO'-
,UNISTR(-
'32MB \ce90\c2dc /M'-
),UNISTR(-
'32MB \c774\c911\d654\b41c \ce90\c2dc \ba54\baa8\b9ac(100MHz '||-
'\b4f1\b85d\b41c SDRAM)'-
));
INSERT INTO product_descriptions VALUES(1755-
,'KO'-
,UNISTR(-
'32MB \ce90\c2dc /NM'-
),UNISTR(-
'32MB \c774\c911\d654\b418\c9c0 \c54a\c740 \ce90\c2dc \ba54\baa8'||-
'\b9ac'-
));
INSERT INTO product_descriptions VALUES(2406-
,'KO'-
,UNISTR(-
'64MB \ce90\c2dc /M'-
),UNISTR(-
'64MB \c774\c911\d654\b41c \ce90\c2dc \ba54\baa8\b9ac'-
));
INSERT INTO product_descriptions VALUES(2404-
,'KO'-
,UNISTR(-
'64MB \ce90\c2dc /NM'-
),UNISTR(-
'64MB \c774\c911\d654\b418\c9c0 \c54a\c740 \ce90\c2dc \ba54\baa8'||-
'\b9ac. FPM \ba54\baa8\b9ac \ce69\c740 5\bcfc\d2b8 SIMM\c5d0\c11c'||-
' \ad6c\d604\b418\c9c0\b9cc 3.3\bcfc\d2b8 DIMM\c5d0\c11c\b3c4 '||-
'\c0ac\c6a9\d560 \c218 \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(1770-
,'KO'-
,UNISTR(-
'8MB \ce90\c2dc /NM'-
),UNISTR(-
'8MB \c774\c911\d654\b418\c9c0 \c54a\c740 \ce90\c2dc \ba54\baa8'||-
'\b9ac(100MHz \b4f1\b85d\b41c SDRAM)'-
));
INSERT INTO product_descriptions VALUES(2412-
,'KO'-
,UNISTR(-
'8MB EDO \ba54\baa8\b9ac'-
),UNISTR(-
'8MB 8x32 EDO SIM \ba54\baa8\b9ac. \d655\c7a5 \b370\c774\d130 '||-
'\cd9c\b825 \ba54\baa8\b9ac\b294 FPM\acfc \d070 \cc28\c774\ac00 '||-
'\c5c6\c9c0\b9cc \b514\c790\c778\c774 \d604\c800\d558\ac8c '||-
'\b2e4\b985\b2c8\b2e4. FPM\acfc \b2ec\b9ac EDO\c758 \b370\c774'||-
'\d130 \cd9c\b825 \b4dc\b77c\c774\bc84\b294 \ba54\baa8\b9ac '||-
'\cee8\d2b8\b864\b7ec\ac00 \b2e4\c74c \c8fc\ae30\b97c \c2dc'||-
'\c791\d558\ae30 \c704\d574 \c5f4 \c8fc\c18c\b97c \c81c\ac70'||-
'\d560 \b54c \b0a8\c544 \c788\c2b5\b2c8\b2e4. \b530\b77c\c11c '||-
'\c774\c804 \c8fc\ae30\ac00 \c644\b8cc\b418\ae30 \c804\c5d0 '||-
'\c0c8 \b370\c774\d130 \c8fc\ae30\b97c \c2dc\c791\d560 \c218 '||-
'\c788\c2b5\b2c8\b2e4. EDO\b294 SIMM \bc0f DIMM, 3.3 \bc0f 5\bcfc'||-
'\d2b8\c5d0\c11c \c0ac\c6a9\d560 \c218 \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2378-
,'KO'-
,UNISTR(-
'DIMM - 128 MB'-
),UNISTR(-
'128MB DIMM \ba54\baa8\b9ac. SIMM\c5d0\c11c DIMM\c73c\b85c \bcc0'||-
'\acbd\b418\b294 \c8fc\c694 \c6d0\c778\c740 64\be44\d2b8 \d504'||-
'\b85c\c138\c11c\c758 \bc84\c2a4 \b108\be44\b97c \bcf4\b2e4 '||-
'\d06c\ac8c \c9c0\c6d0\d558\ae30 \c704\d574\c11c\c785\b2c8\b2e4'||-
'. DIMM\c740 64 \b610\b294 72\be44\d2b8\c774\ba70 SIMM\c740 32 '||-
'\b610\b294 36\be44\d2b8(\d328\b9ac\d2f0 \d3ec\d568)\c785\b2c8'||-
'\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3087-
,'KO'-
,UNISTR(-
'DIMM - 16 MB'-
),UNISTR(-
'Citrus OLX DIMM - \c6a9\b7c9 16MB.'-
));
INSERT INTO product_descriptions VALUES(2384-
,'KO'-
,UNISTR(-
'DIMM - 1GB'-
),UNISTR(-
'\ba54\baa8\b9ac DIMM: RAM - \c6a9\b7c9 1GB.'-
));
INSERT INTO product_descriptions VALUES(1749-
,'KO'-
,UNISTR(-
'DIMM - 256MB'-
),UNISTR(-
'\ba54\baa8\b9ac DIMM: RAM 256MB. (100MHz \b4f1\b85d\b41c SDRAM)'-
));
INSERT INTO product_descriptions VALUES(1750-
,'KO'-
,UNISTR(-
'DIMM - 2GB'-
),UNISTR(-
'\ba54\baa8\b9ac DIMM: RAM, \c6a9\b7c9 2GB.'-
));
INSERT INTO product_descriptions VALUES(2394-
,'KO'-
,UNISTR(-
'DIMM - 32MB'-
),UNISTR(-
'32MB DIMM \ba54\baa8\b9ac \c5c5\adf8\b808\c774\b4dc'-
));
INSERT INTO product_descriptions VALUES(2400-
,'KO'-
,UNISTR(-
'DIMM - 512 MB'-
),UNISTR(-
'512MB DIMM \ba54\baa8\b9ac. \ac1c\c120\b41c \ba54\baa8\b9ac '||-
'\c5c5\adf8\b808\c774\b4dc \c635\c158: \c2dc\c2a4\d15c\c744 '||-
'\c5c5\adf8\b808\c774\b4dc\d560 \b54c \b3d9\c77c\d55c \c2dc'||-
'\c2a4\d15c\c5d0\c11c SIMM\c744 \c0ac\c6a9\d560 \acbd\c6b0 \d544'||-
'\c694\d55c \ac83\bcf4\b2e4 \c801\c740 DIMM\c744 \d544\c694\b85c'||-
' \d569\b2c8\b2e4. \c99d\ac00\b41c \cd5c\b300 \ba54\baa8\b9ac '||-
'\d55c\b3c4: \b3d9\c77c\d55c \c218\c758 \ba54\baa8\b9ac \c2ac'||-
'\b86f\c774 \c81c\acf5\b41c \acbd\c6b0 DIMM\c744 \c0ac\c6a9\d558'||-
'\b294 \c2dc\c2a4\d15c\c758 \cd5c\b300 \ba54\baa8\b9ac\ac00 SIMM'||-
'\c744 \c0ac\c6a9\d558\b294 \c2dc\c2a4\d15c\bcf4\b2e4 \d07d'||-
'\b2c8\b2e4. DIMM\c740 \ac01 \bcf4\b4dc\c5d0 \bcc4\b3c4\b85c '||-
'\c811\c18d\d558\bbc0\b85c \d558\b098\c758 SIMM\bcf4\b2e4 \b450 '||-
'\bc30 \be60\b978 \b370\c774\d130 \c18d\b3c4\b97c \c81c\acf5'||-
'\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(1763-
,'KO'-
,UNISTR(-
'DIMM - 64MB'-
),UNISTR(-
'\ba54\baa8\b9ac DIMM: RAM, 64MB(100MHz \b4f1\b85d\b418\c9c0 \c54a'||-
'\c740 ECC SDRAM)'-
));
INSERT INTO product_descriptions VALUES(2396-
,'KO'-
,UNISTR(-
'EDO - 32MB'-
),UNISTR(-
'\ba54\baa8\b9ac EDO SIM: RAM, 32MB(100MHz \b4f1\b85d\b418\c9c0 '||-
'\c54a\c740 ECC SDRAM). FPM\acfc \ac19\c774 EDO\b294 SIMM\acfc DIMM,'||-
' 3.3 \bc0f 5\bcfc\d2b8\c5d0\c11c \c0ac\c6a9\d560 \c218 \c788'||-
'\c2b5\b2c8\b2e4. EDO \ba54\baa8\b9ac\ac00 \c9c0\c6d0\b418\c9c0 '||-
'\c54a\b294 \cef4\d4e8\d130\c5d0 \c124\ce58\b41c \acbd\c6b0 '||-
'\ba54\baa8\b9ac\ac00 \c791\b3d9\d558\c9c0 \c54a\c744 \c218 '||-
'\c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2272-
,'KO'-
,UNISTR(-
'RAM - 16 MB'-
),UNISTR(-
'\ba54\baa8\b9ac SIMM: RAM - \c6a9\b7c9 16MB.'-
));
INSERT INTO product_descriptions VALUES(2274-
,'KO'-
,UNISTR(-
'RAM - 32 MB'-
),UNISTR(-
'\ba54\baa8\b9ac SIMM: RAM - \c6a9\b7c9 32MB.'-
));
INSERT INTO product_descriptions VALUES(3090-
,'KO'-
,UNISTR(-
'RAM - 48 MB'-
),UNISTR(-
'\b7a8, SIMM - \c6a9\b7c9 48MB.'-
));
INSERT INTO product_descriptions VALUES(1739-
,'KO'-
,UNISTR(-
'SDRAM - 128 MB'-
),UNISTR(-
'SDRAM \ba54\baa8\b9ac, \c6a9\b7c9 128MB. SDRAM\c740 \b370\c774'||-
'\d130\c5d0 100MHz\c758 \c18d\b3c4\b85c \c561\c138\c2a4\d560 '||-
'\c218 \c788\c2b5\b2c8\b2e4. \c774 \c18d\b3c4\b294 \d45c\c900 DR'||-
'AM\bcf4\b2e4 \b124 \bc30\ae4c\c9c0 \be60\b985\b2c8\b2e4. SDRAM'||-
'\c758 \c7a5\c810\c740 \b69c\b837\d558\c9c0\b9cc SDRAM\c744 '||-
'\c9c0\c6d0\d558\b3c4\b85d \c124\acc4\b41c \cef4\d4e8\d130\c5d0'||-
'\c11c\b9cc \c0ac\c6a9\d560 \c218 \c788\c2b5\b2c8\b2e4. SDRAM'||-
'\c740 5 \bc0f 3.3\bcfc\d2b8 DIMM\c5d0\c11c \c0ac\c6a9\d560 \c218'||-
' \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3359-
,'KO'-
,UNISTR(-
'SDRAM - 16 MB'-
),UNISTR(-
'SDRAM \ba54\baa8\b9ac \c5c5\adf8\b808\c774\b4dc \baa8\b4c8. 16MB'||-
'. SDRAM(Synchronous Dynamic Random Access Memory)\c740 EDO \c774\d6c4'||-
'\c5d0 \b3c4\c785\b418\c5c8\c2b5\b2c8\b2e4. \ad6c\c870 \bc0f '||-
'\c791\c5c5\c740 \d45c\c900 DRAM\c758 \ad6c\c870\c640 \c791\c5c5'||-
'\c5d0 \c900\d558\c9c0\b9cc SDRAM\c740 \ae30\bcf8 \ba54\baa8'||-
'\b9ac\b97c \d68d\ae30\c801\c73c\b85c \bcc0\acbd\d558\c5ec '||-
'\b370\c774\d130 \ac80\c0c9 \c2dc\ac04\c744 \d06c\ac8c \c904'||-
'\c600\c2b5\b2c8\b2e4. SDRAM\c740 CPU\b97c \c81c\c5b4\d558\b294 '||-
'\c2dc\c2a4\d15c \c2dc\acc4\c640 \b3d9\ae30\d654\b429\b2c8\b2e4'||-
'. \c989 \b9c8\c774\d06c\b85c\d504\b85c\c138\c11c\c758 \ae30'||-
'\b2a5\c744 \c81c\c5b4\d558\b294 \c2dc\c2a4\d15c \c2dc\acc4'||-
'\ac00 SDRAM \ae30\b2a5\b3c4 \c81c\c5b4\d569\b2c8\b2e4. \c774'||-
'\b97c \d1b5\d574 \ba54\baa8\b9ac \cee8\d2b8\b864\b7ec\b294 '||-
'\b370\c774\d130 \c694\ccad\c774 \c900\be44\b418\b294 \c2dc'||-
'\acc4 \c8fc\ae30\b97c \c54c \c218 \c788\c73c\ba70 \d0c0\c774'||-
'\bc0d \c9c0\c5f0\c744 \bc29\c9c0\d560 \c218 \c788\c2b5\b2c8'||-
'\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3088-
,'KO'-
,UNISTR(-
'SDRAM - 32 MB'-
),UNISTR(-
'ECC\ac00 \c788\b294 SDRAM \baa8\b4c8 - \c6a9\b7c9 32MB. SDRAM\c740'||-
' \b3d9\c2dc\c5d0 \c791\b3d9\d560 \c218 \c788\b294 \c5ec\b7ec '||-
'\ba54\baa8\b9ac \bc45\d06c\b97c \ac00\c9d1\b2c8\b2e4. \bc45'||-
'\d06c\ac04 \c804\d658\c744 \d1b5\d574 \c5f0\c18d \b370\c774'||-
'\d130 \d750\b984\c774 \ac00\b2a5\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2276-
,'KO'-
,UNISTR(-
'SDRAM - 48 MB'-
),UNISTR(-
'\ba54\baa8\b9ac SIMM: RAM - 48MB. SDRAM\c740 \bc84\c2a4\d2b8 \baa8'||-
'\b4dc\b85c \c791\b3d9\d560 \c218 \c788\c2b5\b2c8\b2e4. \bc84'||-
'\c2a4\d2b8 \baa8\b4dc\c5d0\c11c\b294 \b2e8\c77c \b370\c774'||-
'\d130 \c8fc\c18c\ac00 \c561\c138\c2a4\b418\ba74 \d558\b098'||-
'\ac00 \c544\b2cc \c804\ccb4 \b370\c774\d130 \be14\b85d\c774 '||-
'\ac80\c0c9\b429\b2c8\b2e4. \c694\ccad\b420 \b2e4\c74c \b370'||-
'\c774\d130 \c870\ac01\c774 \c774\c804 \c870\ac01\acfc \c5f0'||-
'\c18d\b41c\b2e4\b294 \ac83\c744 \c804\c81c\b85c \d569\b2c8'||-
'\b2e4. \b300\bd80\bd84 \c774 \acbd\c6b0\c5d0 \d574\b2f9\b418'||-
'\bbc0\b85c \b370\c774\d130\b97c \c989\c2dc \c0ac\c6a9\d560 '||-
'\c218 \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3086-
,'KO'-
,UNISTR(-
'VRAM - 16 MB'-
),UNISTR(-
'Citrus Video RAM \baa8\b4c8 - \c6a9\b7c9 16MB. VRAM\c740 \cef4\d4e8'||-
'\d130\c758 \be44\b514\c624 \c2dc\c2a4\d15c\c774 \be44\b514'||-
'\c624 \c815\bcf4\b97c \c800\c7a5\d558\b294 \b370 \c0ac\c6a9'||-
'\d558\ba70 \be44\b514\c624 \c791\c5c5\c5d0\b9cc \c0ac\c6a9'||-
'\b429\b2c8\b2e4. \be44\b514\c624 \d654\ba74\c744 \c0c8\b85c '||-
'\ace0\ce58\b294 \b370 \c9c1\b82c \b370\c774\d130\c758 \c5f0'||-
'\c18d \c2a4\d2b8\b9bc\c744 \c81c\acf5\d558\ae30 \c704\d574 '||-
'\ac1c\bc1c\b418\c5c8\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3091-
,'KO'-
,UNISTR(-
'VRAM - 64 MB'-
),UNISTR(-
'Citrus Video RAM \ba54\baa8\b9ac \baa8\b4c8 - \c6a9\b7c9 64MB. '||-
'\bb3c\b9ac\c801\c73c\b85c VRAM\c740 \c774\b3d9 \b808\c9c0\c2a4'||-
'\d130\b77c\ace0 \d558\b294 \d558\b4dc\c6e8\c5b4\ac00 \cd94'||-
'\ac00\b41c DRAM\acfc \b9e4\c6b0 \c720\c0ac\d569\b2c8\b2e4. VRAM'||-
'\c758 \d2b9\c218 \ae30\b2a5\c740 \d558\b098\c758 \c804\ccb4 '||-
'\b370\c774\d130 \d589(256\be44\d2b8\ae4c\c9c0)\c744 \b2e8\c77c '||-
'\c2dc\acc4 \c8fc\ae30 \b3d9\c548 \c774 \c774\b3d9 \b808\c9c0'||-
'\c2a4\d130\c5d0 \c804\b2ec\d560 \c218 \c788\b294 \ae30\b2a5'||-
'\c785\b2c8\b2e4. \c774 \ae30\b2a5\c744 \d1b5\d574 \c778\cd9c '||-
'\c218\b97c 256\c5d0\c11c \b2e8\c77c \c778\cd9c\b85c \ac10\c18c'||-
'\c2dc\d0ac \c218 \c788\c73c\bbc0\b85c \ac80\c0c9 \c2dc\ac04'||-
'\c744 \d06c\ac8c \c904\c77c \c218 \c788\c2b5\b2c8\b2e4. \b370'||-
'\c774\d130 \b364\d504\c5d0 \b300\d574 \c774\b3d9 \b808\c9c0'||-
'\c2a4\d130\b97c \c0ac\c6a9\d558\ba74 CPU\ac00 \b370\c774\d130'||-
'\b97c \ac80\c0c9\d558\c9c0 \c54a\ace0 \d654\ba74\c744 \c0c8'||-
'\b85c \ace0\ce60 \c218 \c788\c5b4 \b370\c774\d130 \b300\c5ed'||-
'\d3ed\c774 \b450 \bc30\b85c \c99d\ac00\b41c\b2e4\b294 \d070 '||-
'\c774\c810\c774 \c788\c2b5\b2c8\b2e4. \c774\b7ec\d55c \c774'||-
'\c720\b85c VRAM\c740 \c774\c911 \d3ec\d2b8\b77c\ace0\b3c4 \d569'||-
'\b2c8\b2e4. \d558\c9c0\b9cc \c774\b3d9 \b808\c9c0\c2a4\d130'||-
'\b294 VRAM \ce69\c744 \adf8\b7ec\d55c \c6a9\b3c4\b85c \c0ac'||-
'\c6a9\d558\b77c\b294 \d2b9\bcc4 \ba85\b839\c774 \c81c\acf5'||-
'\b420 \b54c\b9cc \c0ac\c6a9\b429\b2c8\b2e4. \c774\b3d9 \b808'||-
'\c9c0\c2a4\d130\b97c \c0ac\c6a9\d558\b294 \ba85\b839\c740 '||-
'\adf8\b798\d53d \cee8\d2b8\b864\b7ec\c5d0 \ad6c\cd95\b429\b2c8'||-
'\b2e4.'-
));
INSERT INTO product_descriptions VALUES(1787-
,'KO'-
,UNISTR(-
'CPU D300'-
),UNISTR(-
'\c774\c911 CPU @ 300Mhz. \c18c\d615 \ac1c\c778 \d504\b85c\c138'||-
'\c2f1 \c804\c6a9 \b610\b294 5\ba85 \bbf8\b9cc\c758 \b3d9\c2dc '||-
'\c0ac\c6a9\c790\b97c \ac00\c9c0\b294 \d30c\c77c \c11c\bc84'||-
'\b85c \c774 \c81c\d488\c740 \ac00\ae4c\c6b4 \c2dc\c77c \b0b4'||-
'\c5d0 \d3d0\ae30\b420 \c608\c815\c785\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2439-
,'KO'-
,UNISTR(-
'CPU D400'-
),UNISTR(-
'\c774\c911 CPU @ 400Mhz. \d0c1\c6d4\d55c \ac00\aca9/\c131\b2a5 '||-
'\be44\c728\b85c \c911\d615 LAN \d30c\c77c \c11c\bc84(\b3d9\c2dc'||-
' \c0ac\c6a9\c790 100\ba85\ae4c\c9c0)\b97c \c704\d55c \ac83\c785'||-
'\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(1788-
,'KO'-
,UNISTR(-
'CPU D600'-
),UNISTR(-
'\c774\c911 CPU @ 600Mhz. \cd5c\cca8\b2e8\c758 \be60\b978 \c2dc'||-
'\acc4 \c18d\b3c4\b85c \c791\c5c5 \bd80\d558\ac00 \b9ce\c740 WAN'||-
' \c11c\bc84(\b3d9\c2dc \c0ac\c6a9\c790 200\ba85\ae4c\c9c0)\b97c'||-
' \c704\d55c \ac83\c785\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2375-
,'KO'-
,UNISTR(-
'GP 1024x768'-
),UNISTR(-
'\adf8\b798\d53d \d504\b85c\c138\c11c, \d574\c0c1\b3c4 1024 X 768'||-
'\d53d\c140. SPNIX v3.3 \bc0f v4.0\c5d0\c11c 2D \bc0f 3D \c751\c6a9'||-
' \d504\b85c\adf8\b7a8\c6a9\c73c\b85c \ac00\aca9 \b300 \c131'||-
'\b2a5\c774 \d0c1\c6d4\d569\b2c8\b2e4. \b2e8\c77c \ce74\b4dc'||-
'\c5d0\c11c \b450 \baa8\b2c8\d130\b97c \c2e4\d589\d558\c5ec '||-
'\bcf4\ae30 \b2a5\b825\c744 \b450 \bc30\b85c \b298\b9b4 \c218 '||-
'\c788\c2b5\b2c8\b2e4. \b450 \b300\c758 17\c778\ce58 \baa8\b2c8'||-
'\d130\b97c \c0ac\c6a9\d558\ba74 21\c778\ce58 \baa8\b2c8\d130 '||-
'\d55c \b300\bcf4\b2e4 \d070 \d654\ba74 \c601\c5ed\c744 \c0ac'||-
'\c6a9\d560 \c218 \c788\c2b5\b2c8\b2e4. \c5ec\b7ec \c791\c5c5'||-
'\c744 \b3d9\c2dc\c5d0 \c218\d589\d558\ac70\b098 \c5ec\b7ec '||-
'\c18c\c2a4\c5d0\c11c \b370\c774\d130\c5d0 \c790\c8fc \c561'||-
'\c138\c2a4\d558\b294 \c0ac\c6a9\c790\c5d0\ac8c \b9e4\c6b0 '||-
'\c801\d569\d55c \c635\c158\c785\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2411-
,'KO'-
,UNISTR(-
'GP 1280x1024'-
),UNISTR(-
'\adf8\b798\d53d \d504\b85c\c138\c11c, \d574\c0c1\b3c4 1280 X 102'||-
'4\d53d\c140. \c911\ac04 \c218\c900\c758 \ac00\aca9\c5d0 \cd5c'||-
'\c0c1\c704 3D \c131\b2a5: \cd08\b2f9 1500\b9cc\ac1c\c758 Gouraud '||-
'\c170\c774\b529 \c0bc\ac01\d615, MCAD \bc0f DCC \c751\c6a9 \d504'||-
'\b85c\adf8\b7a8\c5d0 \b300\d574 \cd5c\c801\d654\b41c 3D \b4dc'||-
'\b77c\c774\bc84, \c0ac\c6a9\c790 \c815\c758 \c124\c815. \c9c0'||-
'\c6d0\b418\b294 \baa8\b4e0 \d45c\c900 \d574\c0c1\b3c4\c5d0'||-
'\c11c \c2e4\c81c \c0c9\c0c1\c744 \c9c0\c6d0\d558\b294 64MB DDR S'||-
'DRAM \d1b5\d569 \d504\b808\c784 \bc84\d37c.'-
));
INSERT INTO product_descriptions VALUES(1769-
,'KO'-
,UNISTR(-
'GP 800x600'-
),UNISTR(-
'\adf8\b798\d53d \d504\b85c\c138\c11c, \d574\c0c1\b3c4 800 x 600'||-
'\d53d\c140. \ace0\ae09 \c751\c6a9 \d504\b85c\adf8\b7a8\c5d0'||-
'\c11c \ace0\ae09 2D \ae30\b2a5 \b610\b294 \c77c\bc18 3D \c9c0'||-
'\c6d0\c744 \d544\c694\b85c \d558\b294 \c0ac\c6a9\c790\c5d0'||-
'\ac8c \b9e4\c6b0 \c801\d569\d569\b2c8\b2e4. \bcf5\c7a1\d55c '||-
'\baa8\b378\c5d0\c11c \b6f0\c5b4\b09c \c131\b2a5\c744 \bcf4'||-
'\c774\ba70 \c0ac\c6a9\c790\ac00 \b80c\b354\b9c1 \d504\b85c'||-
'\c138\c2a4\c5d0 \c2e0\acbd\c4f0\c9c0 \c54a\ace0 \b514\c790'||-
'\c778\c5d0 \c9d1\c911\d560 \c218 \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2049-
,'KO'-
,UNISTR(-
'MB - S300'-
),UNISTR(-
'PC \c720\d615 \b9c8\b354\bcf4\b4dc, 300 Series.'-
));
INSERT INTO product_descriptions VALUES(2751-
,'KO'-
,UNISTR(-
'MB - S450'-
),UNISTR(-
'PC \c720\d615 \b9c8\b354\bcf4\b4dc, 450 Series.'-
));
INSERT INTO product_descriptions VALUES(3112-
,'KO'-
,UNISTR(-
'MB - S500'-
),UNISTR(-
'PC \c720\d615 \b9c8\b354\bcf4\b4dc, 500 Series.'-
));
INSERT INTO product_descriptions VALUES(2752-
,'KO'-
,UNISTR(-
'MB - S550'-
),UNISTR(-
'PC \c720\d615 \b9c8\b354\bcf4\b4dc, 550 Series.'-
));
INSERT INTO product_descriptions VALUES(2293-
,'KO'-
,UNISTR(-
'MB - S600'-
),UNISTR(-
'\b9c8\b354\bcf4\b4dc, 600 Series.'-
));
INSERT INTO product_descriptions VALUES(3114-
,'KO'-
,UNISTR(-
'MB - S900/650+'-
),UNISTR(-
'PC \b9c8\b354\bcf4\b4dc, 900 Series. 650 \c774\c0c1\c758 \baa8'||-
'\b4e0 \baa8\b378\c5d0 \b300\d55c \d45c\c900 \b9c8\b354\bcf4'||-
'\b4dc.'-
));
INSERT INTO product_descriptions VALUES(3129-
,'KO'-
,UNISTR(-
'\c0ac\c6b4\b4dc \ce74\b4dc STD'-
),UNISTR(-
'\c0ac\c6b4\b4dc \ce74\b4dc - \d45c\c900 \bc84\c804, MIDI \c778'||-
'\d130\d398\c774\c2a4, \b77c\c778 \c785\b825/\cd9c\b825, \c800'||-
'\c784\d53c\b358\c2a4 \b9c8\c774\d06c \c785\b825.'-
));
INSERT INTO product_descriptions VALUES(3133-
,'KO'-
,UNISTR(-
'\be44\b514\c624 \ce74\b4dc /32'-
),UNISTR(-
'\be44\b514\c624 \ce74\b4dc, \ce90\c2dc \ba54\baa8\b9ac 32MB.'-
));
INSERT INTO product_descriptions VALUES(2308-
,'KO'-
,UNISTR(-
'\be44\b514\c624 \ce74\b4dc /E32'-
),UNISTR(-
'3-D ELSA \be44\b514\c624 \ce74\b4dc, \ba54\baa8\b9ac 32MB.'-
));
INSERT INTO product_descriptions VALUES(2496-
,'KO'-
,UNISTR(-
'WSP DA-130'-
),UNISTR(-
'\c800\c7a5 \c601\c5ed \d558\c704 \c7a5\ce58\b97c \c704\d55c '||-
'\c640\c774\b4dc \c800\c7a5 \c601\c5ed \d504\b85c\c138\c11c DA-1'||-
'30.'-
));
INSERT INTO product_descriptions VALUES(2497-
,'KO'-
,UNISTR(-
'WSP DA-290'-
),UNISTR(-
'\c640\c774\b4dc \c800\c7a5 \c601\c5ed \d504\b85c\c138\c11c('||-
'\baa8\b378 DA-290).'-
));
INSERT INTO product_descriptions VALUES(3106-
,'KO'-
,UNISTR(-
'KB 101/EN'-
),UNISTR(-
'\d45c\c900 PC/AT \ace0\ae09 \d0a4\bcf4\b4dc(101/102 \d0a4). \c785'||-
'\b825 \b85c\cf00\c77c: \c601\c5b4(\bbf8\ad6d).'-
));
INSERT INTO product_descriptions VALUES(2289-
,'KO'-
,UNISTR(-
'KB 101/ES'-
),UNISTR(-
'\d45c\c900 PC/AT \ace0\ae09 \d0a4\bcf4\b4dc(101/102 \d0a4). \c785'||-
'\b825 \b85c\cf00\c77c: \c2a4\d398\c778\c5b4.'-
));
INSERT INTO product_descriptions VALUES(3110-
,'KO'-
,UNISTR(-
'KB 101/FR'-
),UNISTR(-
'\d45c\c900 PC/AT \ace0\ae09 \d0a4\bcf4\b4dc(101/102 \d0a4). \c785'||-
'\b825 \b85c\cf00\c77c: \d504\b791\c2a4\c5b4.'-
));
INSERT INTO product_descriptions VALUES(3108-
,'KO'-
,UNISTR(-
'KB E/EN'-
),UNISTR(-
'\d0a4 \c601\c5ed\c774 \bd84\b9ac\b41c \c778\ccb4 \acf5\d559 '||-
'\d0a4\bcf4\b4dc, \bd84\b9ac \ac00\b2a5\d55c \c22b\c790 \d328'||-
'\b4dc. \d0a4 \bc30\ce58: \c601\c5b4(\bbf8\ad6d).'-
));
INSERT INTO product_descriptions VALUES(2058-
,'KO'-
,UNISTR(-
'\b9c8\c6b0\c2a4 +WP'-
),UNISTR(-
'\d3b8\b9ac\d55c \c785\b825 \bc0f \b9c8\c6b0\c2a4 \b3d9\c791'||-
'\c744 \c704\d55c \b9c8\c6b0\c2a4\c640 \c190\baa9 \d328\b4dc'||-
'\c758 \c870\d569.'-
));
INSERT INTO product_descriptions VALUES(2761-
,'KO'-
,UNISTR(-
'\b9c8\c6b0\c2a4 +WP/CL'-
),UNISTR(-
'\d68c\c0ac \b85c\ace0\ac00 \c788\b294 \b9c8\c6b0\c2a4\c640 '||-
'\c190\baa9 \d328\b4dc \c138\d2b8'-
));
INSERT INTO product_descriptions VALUES(3117-
,'KO'-
,UNISTR(-
'\b9c8\c6b0\c2a4 C/E'-
),UNISTR(-
'\cf54\b4dc\ac00 \c5c6\b294 \c778\ccb4 \acf5\d559 \b9c8\c6b0'||-
'\c2a4. \ac00\c7a5 \c0ac\c6a9\d558\ae30 \c27d\ace0 \d3b8\d55c '||-
'\d2b8\b799 \bcfc.'-
));
INSERT INTO product_descriptions VALUES(2056-
,'KO'-
,UNISTR(-
'\b9c8\c6b0\c2a4 \d328\b4dc /CL'-
),UNISTR(-
'\d68c\c0ac \b85c\ace0\ac00 \c788\b294 \d45c\c900 \b9c8\c6b0'||-
'\c2a4 \d328\b4dc'-
));
INSERT INTO product_descriptions VALUES(2211-
,'KO'-
,UNISTR(-
'\c190\baa9 \d328\b4dc'-
),UNISTR(-
'\d0a4\bcf4\b4dc \c0ac\c6a9 \c2dc \c190\baa9\c744 \c9c0\c9c0'||-
'\d558\b294 \d3fc \c2a4\d2b8\b9bd'-
));
INSERT INTO product_descriptions VALUES(2944-
,'KO'-
,UNISTR(-
'\c190\baa9 \d328\b4dc /CL'-
),UNISTR(-
'\d68c\c0ac \b85c\ace0\ac00 \c788\b294 \c190\baa9 \d328\b4dc'-
));
INSERT INTO product_descriptions VALUES(1742-
,'KO'-
,UNISTR(-
'CD-ROM 500/16x'-
),UNISTR(-
'CD \b4dc\b77c\c774\be0c, \c77d\ae30 \c804\c6a9, 16\bc30\c18d, '||-
'\cd5c\b300 \c6a9\b7c9 500MB.'-
));
INSERT INTO product_descriptions VALUES(2402-
,'KO'-
,UNISTR(-
'CD-ROM 600/E/24x'-
),UNISTR(-
'600MB \c678\bd80 24\bc30\c18d CD-ROM \b4dc\b77c\c774\be0c(\c77d'||-
'\ae30 \c804\c6a9).'-
));
INSERT INTO product_descriptions VALUES(2403-
,'KO'-
,UNISTR(-
'CD-ROM 600/I/24x'-
),UNISTR(-
'600MB \b0b4\bd80 \c77d\ae30 \c804\c6a9 CD-ROM \b4dc\b77c\c774'||-
'\be0c, \c77d\ae30 24\bc30\c18d'-
));
INSERT INTO product_descriptions VALUES(1761-
,'KO'-
,UNISTR(-
'CD-ROM 600/I/32x'-
),UNISTR(-
'600MB \b0b4\bd80 CD-ROM \b4dc\b77c\c774\be0c, 32\bc30\c18d(\c77d'||-
'\ae30 \c804\c6a9).'-
));
INSERT INTO product_descriptions VALUES(2381-
,'KO'-
,UNISTR(-
'CD-ROM 8x'-
),UNISTR(-
'CD \b77c\c774\d130, \c77d\ae30 \c804\c6a9, 8\bc30\c18d'-
));
INSERT INTO product_descriptions VALUES(2424-
,'KO'-
,UNISTR(-
'CDW 12/24'-
),UNISTR(-
'CD \b77c\c774\d130, \c4f0\ae30 12\bc30\c18d, \c77d\ae30 24\bc30'||-
'\c18d. \acbd\ace0: \c18d\b3c4\ac00 \b290\b9ac\ba70 \d569\b9ac'||-
'\c801\c778 \ac00\aca9\c5d0 \b354 \b098\c740 \b2e4\b978 \c81c'||-
'\d488\c744 \c0ac\c6a9\d560 \c218 \c788\c73c\bbc0\b85c \ace7 '||-
'\d3d0\ae30\b420 \c608\c815\c785\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(1781-
,'KO'-
,UNISTR(-
'CDW 20/48/E'-
),UNISTR(-
'CD \b77c\c774\d130, \c77d\ae30 48\bc30\c18d, \c4f0\ae30 20\bc30'||-
'\c18d'-
));
INSERT INTO product_descriptions VALUES(2264-
,'KO'-
,UNISTR(-
'CDW 20/48/I'-
),UNISTR(-
'CD-ROM \b4dc\b77c\c774\be0c: \c77d\ae30 20\bc30\c18d, \c4f0\ae30'||-
' 48\bc30\c18d(\b0b4\bd80)'-
));
INSERT INTO product_descriptions VALUES(2260-
,'KO'-
,UNISTR(-
'DFD 1.44/3.5'-
),UNISTR(-
'\c774\c911 \d50c\b85c\d53c \b4dc\b77c\c774\be0c - 1.44MB - 3.5'-
));
INSERT INTO product_descriptions VALUES(2266-
,'KO'-
,UNISTR(-
'DVD 12x'-
),UNISTR(-
'DVD-ROM \b4dc\b77c\c774\be0c: 12\bc30\c18d'-
));
INSERT INTO product_descriptions VALUES(3077-
,'KO'-
,UNISTR(-
'DVD 8x'-
),UNISTR(-
'DVD - ROM \b4dc\b77c\c774\be0c, 8\bc30\c18d. \ace7 \d3d0\ae30'||-
'\b420 \c608\c815\c785\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2259-
,'KO'-
,UNISTR(-
'FD 1.44/3.5'-
),UNISTR(-
'\d50c\b85c\d53c \b4dc\b77c\c774\be0c - \c6a9\b7c9 1.44MB \ace0'||-
'\bc00\b3c4 - 3.5\c778\ce58 \c100\c2dc'-
));
INSERT INTO product_descriptions VALUES(2261-
,'KO'-
,UNISTR(-
'FD 1.44/3.5/E'-
),UNISTR(-
'\d50c\b85c\d53c \b514\c2a4\d06c \b4dc\b77c\c774\be0c - \c6a9'||-
'\b7c9 1.44MB(\ace0\bc00\b3c4) - 3.5\c778\ce58(\c678\bd80)'-
));
INSERT INTO product_descriptions VALUES(3082-
,'KO'-
,UNISTR(-
'\baa8\b380- 56/90/E'-
),UNISTR(-
'\baa8\b380 - \cd08\b2f9 56KB, v.90 PCI Global \d638\d658. \c678'||-
'\bd80. \c804\c6d0 \acf5\ae09\ae30 110V.'-
));
INSERT INTO product_descriptions VALUES(2270-
,'KO'-
,UNISTR(-
'\baa8\b380 - 56/90/I'-
),UNISTR(-
'\baa8\b380 - \cd08\b2f9 56KB, v.90 PCI Global \d638\d658. \b0b4'||-
'\bd80, \d45c\c900 \c100\c2dc(3.5\c778\ce58).'-
));
INSERT INTO product_descriptions VALUES(2268-
,'KO'-
,UNISTR(-
'\baa8\b380 - 56/H/E'-
),UNISTR(-
'\d45c\c900 Hayes \d638\d658 \baa8\b380 - \cd08\b2f9 56KB, \c678'||-
'\bd80. \c804\c6d0 \acf5\ae09\ae30: 220V.'-
));
INSERT INTO product_descriptions VALUES(3083-
,'KO'-
,UNISTR(-
'\baa8\b380 - 56/H/I'-
),UNISTR(-
'\d45c\c900 Hayes \baa8\b380 - \cd08\b2f9 56KB, \b0b4\bd80, \d45c'||-
'\c900 3.5\c778\ce58 \c100\c2dc.'-
));
INSERT INTO product_descriptions VALUES(2374-
,'KO'-
,UNISTR(-
'\baa8\b380 - C/100'-
),UNISTR(-
'DOCSIS/EURODOCSIS 1.0/1.1 \d638\d658 \c678\bd80 \cf00\c774\be14 '||-
'\baa8\b380'-
));
INSERT INTO product_descriptions VALUES(1740-
,'KO'-
,UNISTR(-
'TD 12GB/DAT'-
),UNISTR(-
'\d14c\c774\d504 \b4dc\b77c\c774\be0c - \c6a9\b7c9 12GB, DAT '||-
'\d615\c2dd.'-
));
INSERT INTO product_descriptions VALUES(2409-
,'KO'-
,UNISTR(-
'TD 7GB/8'-
),UNISTR(-
'\d14c\c774\d504 \b4dc\b77c\c774\be0c, \c6a9\b7c9 7GB, 8mm \ce74'||-
'\d2b8\b9ac\c9c0 \d14c\c774\d504.'-
));
INSERT INTO product_descriptions VALUES(2262-
,'KO'-
,UNISTR(-
'ZIP 100'-
),UNISTR(-
'ZIP \b4dc\b77c\c774\be0c, \c6a9\b7c9 100MB(\c678\bd80) \bc0f '||-
'\bcd1\b82c \d3ec\d2b8 \c5f0\acb0 \cf00\c774\be14'-
));
INSERT INTO product_descriptions VALUES(2522-
,'KO'-
,UNISTR(-
'\c804\c9c0 - EL'-
),UNISTR(-
'\b7a9\d1b1 \cef4\d4e8\d130\c6a9 \c218\ba85 \c5f0\c7a5 \c804'||-
'\c9c0'-
));
INSERT INTO product_descriptions VALUES(2278-
,'KO'-
,UNISTR(-
'\c804\c9c0 - NiHM'-
),UNISTR(-
'\b7a9\d1b1 \cef4\d4e8\d130\c6a9 \cda9\c804 NiHM \c804\c9c0'-
));
INSERT INTO product_descriptions VALUES(2418-
,'KO'-
,UNISTR(-
'\c804\c9c0 \bc31\c5c5(DA-130)'-
),UNISTR(-
'LED \d45c\c2dc\ae30\ac00 \c788\b294 \c804\c9c0(\b2e8\c77c) '||-
'\cda9\c804\ae30'-
));
INSERT INTO product_descriptions VALUES(2419-
,'KO'-
,UNISTR(-
'\c804\c9c0 \bc31\c5c5(DA-290)'-
),UNISTR(-
'LED \d45c\c2dc\ae30\ac00 \c788\b294 \c804\c9c0(\b450 \ac1c) '||-
'\cda9\c804\ae30'-
));
INSERT INTO product_descriptions VALUES(3097-
,'KO'-
,UNISTR(-
'\cf00\c774\be14 \cee4\b125\d130 - 32R'-
),UNISTR(-
'\cf00\c774\be14 \cee4\b125\d130 - 32\d540 \b9ac\bcf8'-
));
INSERT INTO product_descriptions VALUES(3099-
,'KO'-
,UNISTR(-
'\cf00\c774\be14 \c5f0\acb0 \c7a5\ce58'-
),UNISTR(-
'\cef4\d4e8\d130 \bc30\c120\c744 \ad6c\c131\d558\ace0 \bb36'||-
'\ae30 \c704\d55c \cf00\c774\be14 \c5f0\acb0 \c7a5\ce58'-
));
INSERT INTO product_descriptions VALUES(2380-
,'KO'-
,UNISTR(-
'\cf00\c774\be14 PR/15/P'-
),UNISTR(-
'15\d53c\d2b8 \bcd1\b82c \d504\b9b0\d130 \cf00\c774\be14'-
));
INSERT INTO product_descriptions VALUES(2408-
,'KO'-
,UNISTR(-
'\cf00\c774\be14 PR/P/6'-
),UNISTR(-
'\d45c\c900 \c13c\d2b8\b85c\b2c9\c2a4 6\d53c\d2b8 \d504\b9b0'||-
'\d130 \cf00\c774\be14, \bcd1\b82c \d3ec\d2b8'-
));
INSERT INTO product_descriptions VALUES(2457-
,'KO'-
,UNISTR(-
'\cf00\c774\be14 PR/S/6'-
),UNISTR(-
'\d45c\c900 RS232 \c9c1\b82c \d504\b9b0\d130 \cf00\c774\be14, 6'||-
'\d53c\d2b8'-
));
INSERT INTO product_descriptions VALUES(2373-
,'KO'-
,UNISTR(-
'\cf00\c774\be14 RS232 10/AF'-
),UNISTR(-
'10\d53c\d2b8 RS232 \cf00\c774\be14\acfc F/F \bc0f 9F/25F \c5b4'||-
'\b311\d130'-
));
INSERT INTO product_descriptions VALUES(1734-
,'KO'-
,UNISTR(-
'\cf00\c774\be14 RS232 10/AM'-
),UNISTR(-
'10\d53c\d2b8 RS232 \cf00\c774\be14\acfc M/M \bc0f 9M/25M \c5b4'||-
'\b311\d130'-
));
INSERT INTO product_descriptions VALUES(1737-
,'KO'-
,UNISTR(-
'\cf00\c774\be14 SCSI 10/FW/ADS'-
),UNISTR(-
'10\d53c\d2b8 SCSI2 F/W Adapt \b300 DSxx0 \cf00\c774\be14'-
));
INSERT INTO product_descriptions VALUES(1745-
,'KO'-
,UNISTR(-
'\cf00\c774\be14 SCSI 20/WD->D'-
),UNISTR(-
'20\d53c\d2b8 SCSI2 \b514\c2a4\d06c \c800\c7a5\c18c \c5f0\acb0 '||-
'\c640\c774\b4dc \cf00\c774\be14'-
));
INSERT INTO product_descriptions VALUES(2982-
,'KO'-
,UNISTR(-
'\b4dc\b77c\c774\be0c \b9c8\c6b4\d2b8 - A'-
),UNISTR(-
'\b4dc\b77c\c774\be0c \b9c8\c6b4\d2b8 \c5b4\c148\be14\b9ac '||-
'\d0a4\d2b8'-
));
INSERT INTO product_descriptions VALUES(3277-
,'KO'-
,UNISTR(-
'\b4dc\b77c\c774\be0c \b9c8\c6b4\d2b8 - A/T'-
),UNISTR(-
'\d0c0\c6cc PC\c6a9 \b4dc\b77c\c774\be0c \b9c8\c6b4\d2b8 \c5b4'||-
'\c148\be14\b9ac \d0a4\d2b8'-
));
INSERT INTO product_descriptions VALUES(2976-
,'KO'-
,UNISTR(-
'\b4dc\b77c\c774\be0c \b9c8\c6b4\d2b8 - D'-
),UNISTR(-
'\b370\c2a4\d06c\d1b1 PC\c6a9 \b4dc\b77c\c774\be0c \b9c8\c6b4'||-
'\d2b8'-
));
INSERT INTO product_descriptions VALUES(3204-
,'KO'-
,UNISTR(-
'\c5d4\bcf4\c774 DS'-
),UNISTR(-
'\c5d4\bcf4\c774 \b3c4\d0b9 \c2a4\d14c\c774\c158'-
));
INSERT INTO product_descriptions VALUES(2638-
,'KO'-
,UNISTR(-
'\c5d4\bcf4\c774 DS/E'-
),UNISTR(-
'\ace0\ae09 \c5d4\bcf4\c774 \b3c4\d0b9 \c2a4\d14c\c774\c158'-
));
INSERT INTO product_descriptions VALUES(3020-
,'KO'-
,UNISTR(-
'\c5d4\bcf4\c774 IC'-
),UNISTR(-
'\c5d4\bcf4\c774 \c778\d130\b137 \cef4\d4e8\d130, \d50c\b7ec'||-
'\adf8 \c564 \d50c\b808\c774'-
));
INSERT INTO product_descriptions VALUES(1948-
,'KO'-
,UNISTR(-
'\c5d4\bcf4\c774 IC/58'-
),UNISTR(-
'58K \baa8\b380\c774 \b0b4\c7a5\b41c \c778\d130\b137 \cef4\d4e8'||-
'\d130'-
));
INSERT INTO product_descriptions VALUES(3003-
,'KO'-
,UNISTR(-
'\b7a9\d1b1 128/12/56/v90/110'-
),UNISTR(-
'\c5d4\bcf4\c774 \b7a9\d1b1, \ba54\baa8\b9ac 128MB, \d558\b4dc '||-
'\b514\c2a4\d06c 12GB, v90 \baa8\b380, 110V \c804\c6d0 \acf5\ae09'||-
'\ae30.'-
));
INSERT INTO product_descriptions VALUES(2999-
,'KO'-
,UNISTR(-
'\b7a9\d1b1 16/8/110'-
),UNISTR(-
'\c5d4\bcf4\c774 \b7a9\d1b1, \ba54\baa8\b9ac 16MB, \d558\b4dc '||-
'\b514\c2a4\d06c 8GB, 110V \c804\c6d0 \acf5\ae09\ae30(\bbf8\ad6d '||-
'\c804\c6a9).'-
));
INSERT INTO product_descriptions VALUES(3000-
,'KO'-
,UNISTR(-
'\b7a9\d1b1 32/10/56'-
),UNISTR(-
'\c5d4\bcf4\c774 \b7a9\d1b1, \ba54\baa8\b9ac 32MB, \d558\b4dc '||-
'\b514\c2a4\d06c 10GB, 56K \baa8\b380, \bc94\c6a9 \c804\c6d0 '||-
'\acf5\ae09\ae30(\c804\d658 \ac00\b2a5).'-
));
INSERT INTO product_descriptions VALUES(3001-
,'KO'-
,UNISTR(-
'\b7a9\d1b1 48/10/56/110'-
),UNISTR(-
'\c5d4\bcf4\c774 \b7a9\d1b1, \ba54\baa8\b9ac 48MB, \d558\b4dc '||-
'\b514\c2a4\d06c 10GB, 56K \baa8\b380, 110V \c804\c6d0 \acf5\ae09'||-
'\ae30.'-
));
INSERT INTO product_descriptions VALUES(3004-
,'KO'-
,UNISTR(-
'\b7a9\d1b1 64/10/56/220'-
),UNISTR(-
'\c5d4\bcf4\c774 \b7a9\d1b1, \ba54\baa8\b9ac 64MB, \d558\b4dc '||-
'\b514\c2a4\d06c 10GB, 56K \baa8\b380, 220V \c804\c6d0 \acf5\ae09'||-
'\ae30.'-
));
INSERT INTO product_descriptions VALUES(3391-
,'KO'-
,UNISTR(-
'PS 110/220'-
),UNISTR(-
'\c804\c6d0 \acf5\ae09\ae30 - \c804\d658 \ac00\b2a5, 110V/220V'-
));
INSERT INTO product_descriptions VALUES(3124-
,'KO'-
,UNISTR(-
'PS 110V /T'-
),UNISTR(-
'\d0c0\c6cc PC\c6a9 \c804\c6d0 \acf5\ae09\ae30, 110V'-
));
INSERT INTO product_descriptions VALUES(1738-
,'KO'-
,UNISTR(-
'PS 110V /US'-
),UNISTR(-
'110V \c804\c6d0 \acf5\ae09\ae30 - US \d638\d658'-
));
INSERT INTO product_descriptions VALUES(2377-
,'KO'-
,UNISTR(-
'PS 110V HS/US'-
),UNISTR(-
'110V \ad50\ccb4 \ac00\b2a5 \c804\c6d0 \acf5\ae09\ae30 - US \d638'||-
'\d658'-
));
INSERT INTO product_descriptions VALUES(2299-
,'KO'-
,UNISTR(-
'PS 12V /P'-
),UNISTR(-
'\c804\c6d0 \acf5\ae09\ae30 - 12v \d734\b300\c6a9'-
));
INSERT INTO product_descriptions VALUES(3123-
,'KO'-
,UNISTR(-
'PS 220V /D'-
),UNISTR(-
'\b370\c2a4\d06c\d1b1 \cef4\d4e8\d130\c6a9 \d45c\c900 \c804'||-
'\c6d0 \acf5\ae09\ae30 220V.'-
));
INSERT INTO product_descriptions VALUES(1748-
,'KO'-
,UNISTR(-
'PS 220V /EUR'-
),UNISTR(-
'220V \c804\c6d0 \acf5\ae09\ae30 \c720\d615 - \c720\b7fd'-
));
INSERT INTO product_descriptions VALUES(2387-
,'KO'-
,UNISTR(-
'PS 220V /FR'-
),UNISTR(-
'220V \c804\c6d0 \acf5\ae09\ae30 \c720\d615 - \d504\b791\c2a4'-
));
INSERT INTO product_descriptions VALUES(2370-
,'KO'-
,UNISTR(-
'PS 220V /HS/FR'-
),UNISTR(-
'220V \d56b\c2a4\c651 \ac00\b2a5 \c804\c6d0 \acf5\ae09\ae30('||-
'\d504\b791\c2a4).'-
));
INSERT INTO product_descriptions VALUES(2311-
,'KO'-
,UNISTR(-
'PS 220V /L'-
),UNISTR(-
'\b7a9\d1b1 \cef4\d4e8\d130\c6a9 \c804\c6d0 \acf5\ae09\ae30 220V'-
));
INSERT INTO product_descriptions VALUES(1733-
,'KO'-
,UNISTR(-
'PS 220V /UK'-
),UNISTR(-
'220V \c804\c6d0 \acf5\ae09\ae30 \c720\d615 - \c601\ad6d'-
));
INSERT INTO product_descriptions VALUES(2878-
,'KO'-
,UNISTR(-
'\b77c\c6b0\d130 - ASR/2W'-
),UNISTR(-
'\d2b9\c218 ALS \b77c\c6b0\d130 - \c778\c99d \acf5\ae09\c790 '||-
'\d544\c694 \d56d\baa9(\c774\c911 \b300\c751)'-
));
INSERT INTO product_descriptions VALUES(2879-
,'KO'-
,UNISTR(-
'\b77c\c6b0\d130 - ASR/3W'-
),UNISTR(-
'\d2b9\c218 ALS \b77c\c6b0\d130 - \c778\c99d \acf5\ae09\c790 '||-
'\d544\c694 \d56d\baa9(3\c911 \b300\c751)'-
));
INSERT INTO product_descriptions VALUES(2152-
,'KO'-
,UNISTR(-
'\b77c\c6b0\d130 - DTMF4'-
),UNISTR(-
'DTMF 4 \d3ec\d2b8 \b77c\c6b0\d130'-
));
INSERT INTO product_descriptions VALUES(3301-
,'KO'-
,UNISTR(-
'\b098\c0ac <B.28.P>'-
),UNISTR(-
'\b098\c0ac: \b18b\c1e0, \d06c\ae30 28mm, Phillips \d5e4\b4dc. '||-
'\d50c\b77c\c2a4\d2f1 \c0c1\c790, \c6a9\c801 500.'-
));
INSERT INTO product_descriptions VALUES(3143-
,'KO'-
,UNISTR(-
'\b098\c0ac <B.28.S>'-
),UNISTR(-
'\b098\c0ac: \b18b\c1e0, \d06c\ae30 28mm, \c77c\c790. \d50c\b77c'||-
'\c2a4\d2f1 \c0c1\c790, \c6a9\c801 500.'-
));
INSERT INTO product_descriptions VALUES(2323-
,'KO'-
,UNISTR(-
'\b098\c0ac <B.32.P>'-
),UNISTR(-
'\b098\c0ac: \b18b\c1e0, \d06c\ae30 32mm, Phillips \d5e4\b4dc. '||-
'\d50c\b77c\c2a4\d2f1 \c0c1\c790, \c6a9\c801 400.'-
));
INSERT INTO product_descriptions VALUES(3134-
,'KO'-
,UNISTR(-
'\b098\c0ac <B.32.S>'-
),UNISTR(-
'\b098\c0ac: \b18b\c1e0, \d06c\ae30 32mm, \c77c\c790. \d50c\b77c'||-
'\c2a4\d2f1 \c0c1\c790, \c6a9\c801 400.'-
));
INSERT INTO product_descriptions VALUES(3139-
,'KO'-
,UNISTR(-
'\b098\c0ac <S.16.S>'-
),UNISTR(-
'\b098\c0ac: \ac15\cca0, \d06c\ae30 16mm, \c77c\c790. \d310\c9c0 '||-
'\c0c1\c790, \c6a9\c801 750.'-
));
INSERT INTO product_descriptions VALUES(3300-
,'KO'-
,UNISTR(-
'\b098\c0ac <S.32.P>'-
),UNISTR(-
'\b098\c0ac: \ac15\cca0, \d06c\ae30 32mm, Phillips \d5e4\b4dc. '||-
'\d50c\b77c\c2a4\d2f1 \c0c1\c790, \c6a9\c801 400.'-
));
INSERT INTO product_descriptions VALUES(2316-
,'KO'-
,UNISTR(-
'\b098\c0ac <S.32.S>'-
),UNISTR(-
'\b098\c0ac: \ac15\cca0, \d06c\ae30 32mm, \c77c\c790. \d50c\b77c'||-
'\c2a4\d2f1 \c0c1\c790, \c6a9\c801 500.'-
));
INSERT INTO product_descriptions VALUES(3140-
,'KO'-
,UNISTR(-
'\b098\c0ac <Z.16.S>'-
),UNISTR(-
'\b098\c0ac: \c544\c5f0, \ae38\c774 16mm, \c77c\c790. \d310\c9c0 '||-
'\c0c1\c790, \c6a9\c801 750.'-
));
INSERT INTO product_descriptions VALUES(2319-
,'KO'-
,UNISTR(-
'\b098\c0ac <Z.24.S>'-
),UNISTR(-
'\b098\c0ac: \c544\c5f0, \d06c\ae30 24mm, \c77c\c790. \d310\c9c0 '||-
'\c0c1\c790, \c6a9\c801 500.'-
));
INSERT INTO product_descriptions VALUES(2322-
,'KO'-
,UNISTR(-
'\b098\c0ac <Z.28.P>'-
),UNISTR(-
'\b098\c0ac: \c544\c5f0, \d06c\ae30 28mm, Phillips \d5e4\b4dc. '||-
'\d310\c9c0 \c0c1\c790, \c6a9\c801 850.'-
));
INSERT INTO product_descriptions VALUES(3178-
,'KO'-
,UNISTR(-
'\c2a4\d504\b808\b4dc\c2dc\d2b8 - SSP/V 2.0'-
),UNISTR(-
'SmartSpread Spreadsheet, Vision \b9b4\b9ac\c2a4 11.1 \bc0f 11.2\c6a9 '||-
'Professional Edition \bc84\c804 2.0. \cd95\c18c \d3ec\c7a5\c740 '||-
'\ace0\ae09 \c18c\d504\d2b8\c6e8\c5b4\c640 \c628\b77c\c778 '||-
'\c124\ba85\c11c\b97c \d3ec\d568\d558\b294 CD-ROM \bc0f \c778'||-
'\c1c4\b41c \c124\ba85\c11c, \c790\c2b5\c11c, \b77c\c774\c13c'||-
'\c2a4 \b4f1\b85d\c744 \d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3179-
,'KO'-
,UNISTR(-
'\c2a4\d504\b808\b4dc\c2dc\d2b8 - SSS/S 2.1'-
),UNISTR(-
'SmartSpread Spreadsheet, SPNIX \b9b4\b9ac\c2a4 4.0\c6a9 Standard Editi'||-
'on \bc84\c804 2.1. \cd95\c18c \d3ec\c7a5\c740 \c18c\d504\d2b8'||-
'\c6e8\c5b4\c640 \c628\b77c\c778 \c124\ba85\c11c\b97c \d3ec'||-
'\d568\d558\b294 CD-ROM \bc0f \c778\c1c4\b41c \c124\ba85\c11c, '||-
'\b77c\c774\c13c\c2a4 \b4f1\b85d\c744 \d3ec\d568\d569\b2c8\b2e4'||-
'.'-
));
INSERT INTO product_descriptions VALUES(3182-
,'KO'-
,UNISTR(-
'\c6cc\b4dc\d504\b85c\c138\c2f1 - SWP/V 4.5'-
),UNISTR(-
'SmartWord Word Processor, Vision \b9b4\b9ac\c2a4 11.x\c6a9 Professiona'||-
'l Edition \bc84\c804 4.5. \cd95\c18c \d3ec\c7a5\c740 \ace0\ae09 '||-
'\c18c\d504\d2b8\c6e8\c5b4\b97c \d3ec\d568\d558\b294 CD-ROM, '||-
'\c778\c1c4\b41c \c124\ba85\c11c \bc0f \b77c\c774\c13c\c2a4 '||-
'\b4f1\b85d\c744 \d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3183-
,'KO'-
,UNISTR(-
'\c6cc\b4dc\d504\b85c\c138\c2f1 - SWS/V 4.5'-
),UNISTR(-
'SmartWord Word Processor, Vision \b9b4\b9ac\c2a4 11.x\c6a9 Standard Ed'||-
'ition \bc84\c804 4.5. \cd95\c18c \d3ec\c7a5\c740 CD-ROM \bc0f '||-
'\b77c\c774\c13c\c2a4 \b4f1\b85d\c744 \d3ec\d568\d569\b2c8\b2e4'||-
'.'-
));
INSERT INTO product_descriptions VALUES(3197-
,'KO'-
,UNISTR(-
'\c2a4\d504\b808\b4dc\c2dc\d2b8 - SSS/V 2.1'-
),UNISTR(-
'SmartSpread Spreadsheet, Vision \b9b4\b9ac\c2a4 11.1 \bc0f 11.2\c6a9 '||-
'Standard Edition \bc84\c804 2.1. \cd95\c18c \d3ec\c7a5\c740 \c18c'||-
'\d504\d2b8\c6e8\c5b4\c640 \c628\b77c\c778 \c124\ba85\c11c\b97c'||-
' \d3ec\d568\d558\b294 CD-ROM, \c778\c1c4\b41c \c124\ba85\c11c, '||-
'\c790\c2b5\c11c \bc0f \b77c\c774\c13c\c2a4 \b4f1\b85d\c744 '||-
'\d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3255-
,'KO'-
,UNISTR(-
'\c2a4\d504\b808\b4dc\c2dc\d2b8 - SSS/CD 2.2B'-
),UNISTR(-
'SmartSpread Spreadsheet, SPNIX \b9b4\b9ac\c2a4 4.1\c6a9 Standard Editi'||-
'on, \bca0\d0c0 \bc84\c804 2.2. CD-ROM \c804\c6a9.'-
));
INSERT INTO product_descriptions VALUES(3256-
,'KO'-
,UNISTR(-
'\c2a4\d504\b808\b4dc\c2dc\d2b8 - SSS/V 2.0'-
),UNISTR(-
'SmartSpread Spreadsheet, Vision \b9b4\b9ac\c2a4 11.0\c6a9 Standard Edi'||-
'tion \bc84\c804 2.0. \cd95\c18c \d3ec\c7a5\c740 \c18c\d504\d2b8'||-
'\c6e8\c5b4\c640 \c628\b77c\c778 \c124\ba85\c11c\b97c \d3ec'||-
'\d568\d558\b294 CD-ROM, \c778\c1c4\b41c \c124\ba85\c11c, \c790'||-
'\c2b5\c11c \bc0f \b77c\c774\c13c\c2a4 \b4f1\b85d\c744 \d3ec'||-
'\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3260-
,'KO'-
,UNISTR(-
'\c6cc\b4dc\d504\b85c\c138\c2f1 - SWP/S 4.4'-
),UNISTR(-
'SmartSpread Spreadsheet, SPNIX \b9b4\b9ac\c2a4 4.x\c6a9 Standard Editi'||-
'on \bc84\c804 2.2. \cd95\c18c \d3ec\c7a5\c740 \c18c\d504\d2b8'||-
'\c6e8\c5b4\b97c \d3ec\d568\d558\b294 CD-ROM, \c778\c1c4\b41c '||-
'\c124\ba85\c11c \bc0f \b77c\c774\c13c\c2a4 \b4f1\b85d\c744 '||-
'\d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3262-
,'KO'-
,UNISTR(-
'\c2a4\d504\b808\b4dc\c2dc\d2b8 - SSS/S 2.2'-
),UNISTR(-
'SmartSpread Spreadsheet, SPNIX \b9b4\b9ac\c2a4 4.1\c6a9 Standard Editi'||-
'on \bc84\c804 2.2. \cd95\c18c \d3ec\c7a5\c740 \c18c\d504\d2b8'||-
'\c6e8\c5b4\c640 \c628\b77c\c778 \c124\ba85\c11c\b97c \d3ec'||-
'\d568\d558\b294 CD-ROM, \c778\c1c4\b41c \c124\ba85\c11c \bc0f '||-
'\b77c\c774\c13c\c2a4 \b4f1\b85d\c744 \d3ec\d568\d569\b2c8\b2e4'||-
'.'-
));
INSERT INTO product_descriptions VALUES(3361-
,'KO'-
,UNISTR(-
'\c2a4\d504\b808\b4dc\c2dc\d2b8 - SSP/S 1.5'-
),UNISTR(-
'SmartSpread Spreadsheet, SPNIX \b9b4\b9ac\c2a4 3.3\c6a9 Standard Editi'||-
'on \bc84\c804 1.5. \cd95\c18c \d3ec\c7a5\c740 \ace0\ae09 \c18c'||-
'\d504\d2b8\c6e8\c5b4 \bc0f \c628\b77c\c778 \c124\ba85\c11c'||-
'\b97c \d3ec\d568\d558\b294 CD-ROM, \c778\c1c4\b41c \c124\ba85'||-
'\c11c, \c790\c2b5\c11c \bc0f \b77c\c774\c13c\c2a4 \b4f1\b85d'||-
'\c744 \d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(1799-
,'KO'-
,UNISTR(-
'SPNIX3.3 - SL'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - '||-
'\ae30\bcf8 \c11c\bc84 \b77c\c774\c13c\c2a4. \c2dc\c2a4\d15c '||-
'\ad00\b9ac, \ac1c\bc1c\c790 \b610\b294 \c0ac\c6a9\c790\c5d0 '||-
'\b300\d55c 10\ac1c\c758 \c77c\bc18 \b77c\c774\c13c\c2a4\b97c '||-
'\d3ec\d568\d569\b2c8\b2e4. \b124\d2b8\c6cc\d06c \c0ac\c6a9'||-
'\c790 \b77c\c774\c13c\c2a4\b294 \c5c6\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(1801-
,'KO'-
,UNISTR(-
'SPNIX3.3 - AL'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - '||-
'\b124\d2b8\c6cc\d06c \c561\c138\c2a4\b97c \d3ec\d568\d55c '||-
'\cd94\ac00 \c2dc\c2a4\d15c \ad00\b9ac\c790 \b77c\c774\c13c'||-
'\c2a4.'-
));
INSERT INTO product_descriptions VALUES(1803-
,'KO'-
,UNISTR(-
'SPNIX3.3 - DL'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - '||-
'\cd94\ac00 \ac1c\bc1c\c790 \b77c\c774\c13c\c2a4.'-
));
INSERT INTO product_descriptions VALUES(1804-
,'KO'-
,UNISTR(-
'SPNIX3.3 - UL/N'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - '||-
'\b124\d2b8\c6cc\d06c \c561\c138\c2a4\b97c \d3ec\d568\d55c '||-
'\cd94\ac00 \c0ac\c6a9\c790 \b77c\c774\c13c\c2a4.'-
));
INSERT INTO product_descriptions VALUES(1805-
,'KO'-
,UNISTR(-
'SPNIX3.3 - UL/A'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - '||-
'\cd94\ac00 \c0ac\c6a9\c790 \b77c\c774\c13c\c2a4 \d074\b798'||-
'\c2a4 A.'-
));
INSERT INTO product_descriptions VALUES(1806-
,'KO'-
,UNISTR(-
'SPNIX3.3 - UL/C'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - '||-
'\cd94\ac00 \c0ac\c6a9\c790 \b77c\c774\c13c\c2a4 \d074\b798'||-
'\c2a4 C.'-
));
INSERT INTO product_descriptions VALUES(1808-
,'KO'-
,UNISTR(-
'SPNIX3.3 - UL/D'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - '||-
'\cd94\ac00 \c0ac\c6a9\c790 \b77c\c774\c13c\c2a4 \d074\b798'||-
'\c2a4 D.'-
));
INSERT INTO product_descriptions VALUES(1820-
,'KO'-
,UNISTR(-
'SPNIX3.3 - NL'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - '||-
'\cd94\ac00 \b124\d2b8\c6cc\d06c \c561\c138\c2a4 \b77c\c774'||-
'\c13c\c2a4.'-
));
INSERT INTO product_descriptions VALUES(1822-
,'KO'-
,UNISTR(-
'SPNIX4.0 - SL'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V4.0 - '||-
'\ae30\bcf8 \c11c\bc84 \b77c\c774\c13c\c2a4. \c2dc\c2a4\d15c '||-
'\ad00\b9ac, \ac1c\bc1c\c790 \b610\b294 \c0ac\c6a9\c790\c5d0 '||-
'\b300\d55c 10\ac1c\c758 \c77c\bc18 \b77c\c774\c13c\c2a4\b97c '||-
'\d3ec\d568\d569\b2c8\b2e4. \b124\d2b8\c6cc\d06c \c0ac\c6a9'||-
'\c790 \b77c\c774\c13c\c2a4\b294 \c5c6\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2422-
,'KO'-
,UNISTR(-
'SPNIX4.0 - SAL'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V4.0 - '||-
'\b124\d2b8\c6cc\d06c \c561\c138\c2a4\b97c \d3ec\d568\d55c '||-
'\cd94\ac00 \c2dc\c2a4\d15c \ad00\b9ac\c790 \b77c\c774\c13c'||-
'\c2a4.'-
));
INSERT INTO product_descriptions VALUES(2452-
,'KO'-
,UNISTR(-
'SPNIX4.0 - DL'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V4.0 - '||-
'\cd94\ac00 \ac1c\bc1c\c790 \b77c\c774\c13c\c2a4.'-
));
INSERT INTO product_descriptions VALUES(2462-
,'KO'-
,UNISTR(-
'SPNIX4.0 - UL/N'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V4.0 - '||-
'\b124\d2b8\c6cc\d06c \c561\c138\c2a4\b97c \d3ec\d568\d55c '||-
'\cd94\ac00 \c0ac\c6a9\c790 \b77c\c774\c13c\c2a4.'-
));
INSERT INTO product_descriptions VALUES(2464-
,'KO'-
,UNISTR(-
'SPNIX4.0 - UL/A'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V4.0 - '||-
'\cd94\ac00 \c0ac\c6a9\c790 \b77c\c774\c13c\c2a4 \d074\b798'||-
'\c2a4 A.'-
));
INSERT INTO product_descriptions VALUES(2467-
,'KO'-
,UNISTR(-
'SPNIX4.0 - UL/D'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V4.0 - '||-
'\cd94\ac00 \c0ac\c6a9\c790 \b77c\c774\c13c\c2a4 \d074\b798'||-
'\c2a4 D.'-
));
INSERT INTO product_descriptions VALUES(2468-
,'KO'-
,UNISTR(-
'SPNIX4.0 - UL/C'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V4.0 - '||-
'\cd94\ac00 \c0ac\c6a9\c790 \b77c\c774\c13c\c2a4 \d074\b798'||-
'\c2a4 C.'-
));
INSERT INTO product_descriptions VALUES(2470-
,'KO'-
,UNISTR(-
'SPNIX4.0 - NL'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V4.0 - '||-
'\cd94\ac00 \b124\d2b8\c6cc\d06c \c561\c138\c2a4 \b77c\c774'||-
'\c13c\c2a4.'-
));
INSERT INTO product_descriptions VALUES(2471-
,'KO'-
,UNISTR(-
'SPNIX3.3 SU'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - '||-
'\ae30\bcf8 \c11c\bc84 \b77c\c774\c13c\c2a4\b97c V4.0\c73c\b85c '||-
'\c5c5\adf8\b808\c774\b4dc.'-
));
INSERT INTO product_descriptions VALUES(2492-
,'KO'-
,UNISTR(-
'SPNIX3.3 AU'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - V4.'||-
'0 \c5c5\adf8\b808\c774\b4dc, \d074\b798\c2a4 A \c0ac\c6a9\c790.'-
));
INSERT INTO product_descriptions VALUES(2493-
,'KO'-
,UNISTR(-
'SPNIX3.3 C/DU'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - V4.'||-
'0 \c5c5\adf8\b808\c774\b4dc, \d074\b798\c2a4 C \b610\b294 D '||-
'\c0ac\c6a9\c790.'-
));
INSERT INTO product_descriptions VALUES(2494-
,'KO'-
,UNISTR(-
'SPNIX3.3 NU'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - V4.'||-
'0 \c5c5\adf8\b808\c774\b4dc, \b124\d2b8\c6cc\d06c \c561\c138'||-
'\c2a4 \b77c\c774\c13c\c2a4.'-
));
INSERT INTO product_descriptions VALUES(2995-
,'KO'-
,UNISTR(-
'SPNIX3.3 SAU'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - V4.'||-
'0 \c5c5\adf8\b808\c774\b4dc, \c2dc\c2a4\d15c \ad00\b9ac\c790 '||-
'\b77c\c774\c13c\c2a4.'-
));
INSERT INTO product_descriptions VALUES(3290-
,'KO'-
,UNISTR(-
'SPNIX3.3 DU'-
),UNISTR(-
'\c6b4\c601 \ccb4\c81c \c18c\d504\d2b8\c6e8\c5b4: SPNIX V3.3 - V4.'||-
'0 \c5c5\adf8\b808\c774\b4dc, \ac1c\bc1c\c790 \b77c\c774\c13c'||-
'\c2a4.'-
));
INSERT INTO product_descriptions VALUES(1778-
,'KO'-
,UNISTR(-
'SPNIX3.3\c6a9 C - \b2e8\c77c \c0ac\c6a9\c790'-
),UNISTR(-
'SPNIX V3.3\c6a9 C \d504\b85c\adf8\b798\bc0d \c18c\d504\d2b8\c6e8'||-
'\c5b4 - \b2e8\c77c \c0ac\c6a9\c790'-
));
INSERT INTO product_descriptions VALUES(1779-
,'KO'-
,UNISTR(-
'SPNIX3.3\c6a9 C - Doc'-
),UNISTR(-
'C \d504\b85c\adf8\b798\bc0d \c5b8\c5b4 \c124\ba85\c11c, SPNIX V3'||-
'.3'-
));
INSERT INTO product_descriptions VALUES(1780-
,'KO'-
,UNISTR(-
'SPNIX3.3\c6a9 C - Sys'-
),UNISTR(-
'SPNIX V3.3\c6a9 C \d504\b85c\adf8\b798\bc0d \c18c\d504\d2b8\c6e8'||-
'\c5b4 - \c2dc\c2a4\d15c \cef4\d30c\c77c\b7ec, \b77c\c774\be0c'||-
'\b7ec\b9ac, \b9c1\cee4'-
));
INSERT INTO product_descriptions VALUES(2371-
,'KO'-
,UNISTR(-
'SPNIX4.0\c6a9 C - Doc'-
),UNISTR(-
'C \d504\b85c\adf8\b798\bc0d \c5b8\c5b4 \c124\ba85\c11c, SPNIX V4'||-
'.0'-
));
INSERT INTO product_descriptions VALUES(2423-
,'KO'-
,UNISTR(-
'SPNIX4.0\c6a9 C - \b2e8\c77c \c0ac\c6a9\c790'-
),UNISTR(-
'SPNIX V4.0\c6a9 C \d504\b85c\adf8\b798\bc0d \c18c\d504\d2b8\c6e8'||-
'\c5b4 - \b2e8\c77c \c0ac\c6a9\c790'-
));
INSERT INTO product_descriptions VALUES(3501-
,'KO'-
,UNISTR(-
'SPNIX4.0\c6a9 C - Sys'-
),UNISTR(-
'SPNIX V4.0\c6a9 C \d504\b85c\adf8\b798\bc0d \c18c\d504\d2b8\c6e8'||-
'\c5b4 - \c2dc\c2a4\d15c \cef4\d30c\c77c\b7ec, \b77c\c774\be0c'||-
'\b7ec\b9ac, \b9c1\cee4'-
));
INSERT INTO product_descriptions VALUES(3502-
,'KO'-
,UNISTR(-
'SPNIX3.3\c6a9 C -Sys/U'-
),UNISTR(-
'SPNIX V3.3\c6a9 C \d504\b85c\adf8\b798\bc0d \c18c\d504\d2b8\c6e8'||-
'\c5b4 - 4.0 \c5c5\adf8\b808\c774\b4dc. \c2dc\c2a4\d15c \cef4'||-
'\d30c\c77c\b7ec, \b77c\c774\be0c\b7ec\b9ac, \b9c1\cee4'-
));
INSERT INTO product_descriptions VALUES(3503-
,'KO'-
,UNISTR(-
'SPNIX3.3\c6a9 C - \c0ac\c6a9\c790/U'-
),UNISTR(-
'SPNIX V3.3\c6a9 C \d504\b85c\adf8\b798\bc0d \c18c\d504\d2b8\c6e8'||-
'\c5b4 - 4.0 \c5c5\adf8\b808\c774\b4dc - \b2e8\c77c \c0ac\c6a9'||-
'\c790'-
));
INSERT INTO product_descriptions VALUES(1774-
,'KO'-
,UNISTR(-
'\ae30\bcf8 ISO CP - BL'-
),UNISTR(-
'\ae30\bcf8 ISO \d1b5\c2e0 \d328\d0a4\c9c0 - \ae30\bcf8 \b77c'||-
'\c774\c13c\c2a4'-
));
INSERT INTO product_descriptions VALUES(1775-
,'KO'-
,UNISTR(-
'\d074\b77c\c774\c5b8\d2b8 ISO CP - S'-
),UNISTR(-
'\cd94\ac00 SPNIX V3.3 \d074\b77c\c774\c5b8\d2b8\b97c \c704\d55c '||-
'ISO \d1b5\c2e0 \d328\d0a4\c9c0 \cd94\ac00 \b77c\c774\c13c\c2a4.'-
));
INSERT INTO product_descriptions VALUES(1794-
,'KO'-
,UNISTR(-
'OSI 8-16/IL'-
),UNISTR(-
'OSI \ce35 8 ~ 16 - \c99d\bd84 \b77c\c774\c13c\c2a4'-
));
INSERT INTO product_descriptions VALUES(1825-
,'KO'-
,UNISTR(-
'X25 - 1\d589 \b77c\c774\c13c\c2a4'-
),UNISTR(-
'X25 \b124\d2b8\c6cc\d06c \c561\c138\c2a4 \c81c\c5b4 \c2dc\c2a4'||-
'\d15c, \b2e8\c77c \c0ac\c6a9\c790'-
));
INSERT INTO product_descriptions VALUES(2004-
,'KO'-
,UNISTR(-
'IC \be0c\b77c\c6b0\c800 - S'-
),UNISTR(-
'SPNIX\c6a9 IC \c6f9 \be0c\b77c\c6b0\c800. \b124\d2b8\c6cc\d06c '||-
'\ba54\c77c \ae30\b2a5\c774 \c788\b294 \be0c\b77c\c6b0\c800.'-
));
INSERT INTO product_descriptions VALUES(2005-
,'KO'-
,UNISTR(-
'IC \be0c\b77c\c6b0\c800 Doc - S'-
),UNISTR(-
'SPNIX\c6a9 IC Web Browser \c124\ba85\c11c \baa8\c74c. Installation M'||-
'anual, Mail Server Administration Guide \bc0f User Quick Reference\b97c '||-
'\d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2416-
,'KO'-
,UNISTR(-
'\d074\b77c\c774\c5b8\d2b8 ISO CP - S'-
),UNISTR(-
'\cd94\ac00 SPNIX V4.0 \d074\b77c\c774\c5b8\d2b8\b97c \c704\d55c '||-
'ISO \d1b5\c2e0 \d328\d0a4\c9c0 \cd94\ac00 \b77c\c774\c13c\c2a4.'-
));
INSERT INTO product_descriptions VALUES(2417-
,'KO'-
,UNISTR(-
'\d074\b77c\c774\c5b8\d2b8 ISO CP - V'-
),UNISTR(-
'\cd94\ac00 Vision \d074\b77c\c774\c5b8\d2b8\b97c \c704\d55c ISO '||-
'\d1b5\c2e0 \d328\d0a4\c9c0 \cd94\ac00 \b77c\c774\c13c\c2a4.'-
));
INSERT INTO product_descriptions VALUES(2449-
,'KO'-
,UNISTR(-
'OSI 1-4/IL'-
),UNISTR(-
'OSI \ce35 1 ~ 4 - \c99d\bd84 \b77c\c774\c13c\c2a4'-
));
INSERT INTO product_descriptions VALUES(3101-
,'KO'-
,UNISTR(-
'IC \be0c\b77c\c6b0\c800 - V'-
),UNISTR(-
'Vision\c6a9 IC Web Browser(\c124\ba85\c11c \d3ec\d568). \b124\d2b8'||-
'\c6cc\d06c \ba54\c77c \ae30\b2a5 \c9c0\c6d0 \be0c\b77c\c6b0'||-
'\c800.'-
));
INSERT INTO product_descriptions VALUES(3170-
,'KO'-
,UNISTR(-
'Smart Suite - V/SP'-
),UNISTR(-
'Vision\c6a9 Office Suite(SmartWrite, SmartArt, SmartSpread, SmartBrowse).'||-
' \c2a4\d398\c778\c5b4 \c18c\d504\d2b8\c6e8\c5b4 \bc0f \c0ac'||-
'\c6a9\c790 \c124\ba85\c11c.'-
));
INSERT INTO product_descriptions VALUES(3171-
,'KO'-
,UNISTR(-
'Smart Suite - S3.3/EN'-
),UNISTR(-
'SPNIX Version 3.3\c6a9 Office Suite(SmartWrite, SmartArt, SmartSpread, Sm'||-
'artBrowse). \c601\c5b4 \c18c\d504\d2b8\c6e8\c5b4 \bc0f \c0ac'||-
'\c6a9\c790 \c124\ba85\c11c.'-
));
INSERT INTO product_descriptions VALUES(3172-
,'KO'-
,UNISTR(-
'Graphics - DIK+'-
),UNISTR(-
'Software Kit Graphics: Draw-It Kwik-Plus. \ad11\bc94\c704\d55c \d074'||-
'\b9bd \c544\d2b8 \d30c\c77c \bc0f 3D \ac1c\ccb4 \c870\c791\c744'||-
' \c704\d55c \ace0\ae09 \b4dc\b85c\c789 \d234, \b2e4\c591\d55c '||-
'\c74c\c601 \d6a8\acfc, \d655\c7a5 \bb38\c790 \ae00\af34 \b4f1'||-
'\c744 \d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3173-
,'KO'-
,UNISTR(-
'Graphics - SA'-
),UNISTR(-
'Software Kit Graphics: SmartArt. SPNIX\c6a9 \c804\bb38 \adf8\b798'||-
'\d53d \d328\d0a4\c9c0\b85c \c5ec\b7ec \c120 \c2a4\d0c0\c77c, '||-
'\c9c8\ac10, \b0b4\c7a5 \baa8\c591 \bc0f \c77c\bc18 \ae30\d638'||-
'\b97c \d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3175-
,'KO'-
,UNISTR(-
'Project Management - S4.0'-
),UNISTR(-
'SPNIX V4.0\c6a9 \d504\b85c\c81d\d2b8 \ad00\b9ac \c18c\d504\d2b8'||-
'\c6e8\c5b4. \d14d\c2a4\d2b8, \adf8\b798\d53d, \c2a4\d504\b808'||-
'\b4dc\c2dc\d2b8 \bc0f \c0ac\c6a9\c790\ac00 \c815\c758\d560 '||-
'\c218 \c788\b294 \bcf4\ace0\c11c \d615\c2dd\acfc \d568\aed8 '||-
'\ba85\b839\d589 \bc0f \adf8\b798\d53d \c778\d130\d398\c774'||-
'\c2a4\b97c \d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3176-
,'KO'-
,UNISTR(-
'Smart Suite - V/EN'-
),UNISTR(-
'Vision\c6a9 Office Suite(SmartWrite, SmartArt, SmartSpread, SmartBrowse).'||-
' \c601\c5b4 \c18c\d504\d2b8\c6e8\c5b4 \bc0f \c0ac\c6a9\c790 '||-
'\c124\ba85\c11c.'-
));
INSERT INTO product_descriptions VALUES(3177-
,'KO'-
,UNISTR(-
'Smart Suite - V/FR'-
),UNISTR(-
'Vision\c6a9 Office Suite(SmartWrite, SmartArt, SmartSpread, SmartBrowse).'||-
' \d504\b791\c2a4\c5b4 \c18c\d504\d2b8\c6e8\c5b4 \bc0f \c0ac'||-
'\c6a9\c790 \c124\ba85\c11c.'-
));
INSERT INTO product_descriptions VALUES(3245-
,'KO'-
,UNISTR(-
'Smart Suite - S4.0/FR'-
),UNISTR(-
'SPNIX V4.0\c6a9 Office Suite(SmartWrite, SmartArt, SmartSpread, SmartBrow'||-
'se). \d504\b791\c2a4\c5b4 \c18c\d504\d2b8\c6e8\c5b4 \bc0f \c0ac'||-
'\c6a9\c790 \c124\ba85\c11c.'-
));
INSERT INTO product_descriptions VALUES(3246-
,'KO'-
,UNISTR(-
'Smart Suite - S4.0/SP'-
),UNISTR(-
'SPNIX V4.0\c6a9 Office Suite(SmartWrite, SmartArt, SmartSpread, SmartBrow'||-
'se). \c2a4\d398\c778\c5b4 \c18c\d504\d2b8\c6e8\c5b4 \bc0f \c0ac'||-
'\c6a9\c790 \c124\ba85\c11c.'-
));
INSERT INTO product_descriptions VALUES(3247-
,'KO'-
,UNISTR(-
'Smart Suite - V/DE'-
),UNISTR(-
'Vision\c6a9 Office Suite(SmartWrite, SmartArt, SmartSpread, SmartBrowse).'||-
' \b3c5\c77c\c5b4 \c18c\d504\d2b8\c6e8\c5b4 \bc0f \c0ac\c6a9'||-
'\c790 \c124\ba85\c11c.'-
));
INSERT INTO product_descriptions VALUES(3248-
,'KO'-
,UNISTR(-
'Smart Suite - S4.0/DE'-
),UNISTR(-
'SPNIX V4.0\c6a9 Office Suite(SmartWrite, SmartArt, SmartSpread, SmartBrow'||-
'se). \b3c5\c77c\c5b4 \c18c\d504\d2b8\c6e8\c5b4 \bc0f \c0ac\c6a9'||-
'\c790 \c124\ba85\c11c.'-
));
INSERT INTO product_descriptions VALUES(3250-
,'KO'-
,UNISTR(-
'Graphics - DIK'-
),UNISTR(-
'Software Kit Graphics: Draw-It Kwik. Vision \c2dc\c2a4\d15c\c744 '||-
'\c704\d55c \ac04\b2e8\d55c \adf8\b798\d53d \d328\d0a4\c9c0'||-
'\b85c GIF, JPG \bc0f BMP \d615\c2dd\c73c\b85c \c800\c7a5\d558'||-
'\b294 \c635\c158\c744 \d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3251-
,'KO'-
,UNISTR(-
'Project Management - V'-
),UNISTR(-
'Vision\c6a9 \d504\b85c\c81d\d2b8 \ad00\b9ac \c18c\d504\d2b8'||-
'\c6e8\c5b4. \d14d\c2a4\d2b8, \adf8\b798\d53d, \c2a4\d504\b808'||-
'\b4dc\c2dc\d2b8 \bc0f \c0ac\c6a9\c790\ac00 \c815\c758\d560 '||-
'\c218 \c788\b294 \bcf4\ace0\c11c \d615\c2dd\acfc \d568\aed8 '||-
'\ba85\b839\d589 \bc0f \adf8\b798\d53d \c778\d130\d398\c774'||-
'\c2a4\b97c \d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3252-
,'KO'-
,UNISTR(-
'Project Management - S3.3'-
),UNISTR(-
'SPNIX V3.3\c6a9 \d504\b85c\c81d\d2b8 \ad00\b9ac \c18c\d504\d2b8'||-
'\c6e8\c5b4. \d14d\c2a4\d2b8, \adf8\b798\d53d, \c2a4\d504\b808'||-
'\b4dc\c2dc\d2b8 \bc0f \c0ac\c6a9\c790\ac00 \c815\c758\d560 '||-
'\c218 \c788\b294 \bcf4\ace0\c11c \d615\c2dd\acfc \d568\aed8 '||-
'\ba85\b839\d589 \bc0f \adf8\b798\d53d \c778\d130\d398\c774'||-
'\c2a4\b97c \d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3253-
,'KO'-
,UNISTR(-
'Smart Suite - S4.0/EN'-
),UNISTR(-
'SPNIX V4.0\c6a9 Office Suite(SmartWrite, SmartArt, SmartSpread, SmartBrow'||-
'se). \c601\c5b4 \c18c\d504\d2b8\c6e8\c5b4 \bc0f \c0ac\c6a9\c790'||-
' \c124\ba85\c11c.'-
));
INSERT INTO product_descriptions VALUES(3257-
,'KO'-
,UNISTR(-
'\c6f9 \be0c\b77c\c6b0\c800 - SB/S 2.1'-
),UNISTR(-
'Software Kit Web Browser: SPNIX V3.3\c6a9 SmartBrowse V2.1. \bb38\b9e5'||-
'\c5d0 \b530\b978 \b3c4\c6c0\b9d0 \d30c\c77c\acfc \c628\b77c'||-
'\c778 \c124\ba85\c11c\b97c \d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3258-
,'KO'-
,UNISTR(-
'\c6f9 \be0c\b77c\c6b0\c800 - SB/V 1.0'-
),UNISTR(-
'Software Kit Web Browser: Vision\c6a9 SmartBrowse V2.1. \bb38\b9e5'||-
'\c5d0 \b530\b978 \b3c4\c6c0\b9d0 \d30c\c77c\acfc \c628\b77c'||-
'\c778 \c124\ba85\c11c\b97c \d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3362-
,'KO'-
,UNISTR(-
'\c6f9 \be0c\b77c\c6b0\c800 - SB/S 4.0'-
),UNISTR(-
'Software Kit Web Browser: SPNIX V4.0\c6a9 SmartBrowse V4.0. \bb38\b9e5'||-
'\c5d0 \b530\b978 \b3c4\c6c0\b9d0 \d30c\c77c\acfc \c628\b77c'||-
'\c778 \c124\ba85\c11c\b97c \d3ec\d568\d569\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2231-
,'KO'-
,UNISTR(-
'\cc45\c0c1 - S/V'-
),UNISTR(-
'\d45c\c900 \d06c\ae30 \cc45\c0c1. \c790\c0b0 \b300\c0c1, \c138'||-
'\ae08 \bd80\acfc \d56d\baa9. \c8fc\bb38 \c2dc \c624\d06c, \bb3c'||-
'\d478\b808, \bc9a\b098\bb34 \bc0f \b9c8\d638\ac00\b2c8 \b4f1'||-
'\c758 \c7ac\ace0 \d654\c7a5\d310\c73c\b85c \b9c8\c9c0\b9c9 '||-
'\b9c8\bb34\b9ac.'-
));
INSERT INTO product_descriptions VALUES(2335-
,'KO'-
,UNISTR(-
'\c774\b3d9 \c804\d654'-
),UNISTR(-
'\c804\c9c0 \c18c\be44\ac00 \c801\c740 \c774\c911 \bc34\b4dc '||-
'\c774\b3d9 \c804\d654. \ac00\bcbc\c6b4 \d3f4\b354\d615, \b2e8'||-
'\c77c \c774\c5b4\d3f0 \c18c\cf13 \bc0f \c608\be44 \c804\c9c0 '||-
'\d3ec\d568.'-
));
INSERT INTO product_descriptions VALUES(2350-
,'KO'-
,UNISTR(-
'\cc45\c0c1 - W/48'-
),UNISTR(-
'\cc45\c0c1 - \cd5c\c800\ac00 48\c778\ce58 \d770\c0c9 \d569\d310'||-
' \c81c\d488, \c790\c0b0 \b300\c0c1, \c138\ae08 \bd80\acfc \d56d'||-
'\baa9.'-
));
INSERT INTO product_descriptions VALUES(2351-
,'KO'-
,UNISTR(-
'\cc45\c0c1 - W/48/R'-
),UNISTR(-
'\cc45\c0c1 - 60\c778\ce58 \d770\c0c9 \d569\d310 \c81c\d488, '||-
'\c790\c0b0 \b300\c0c1, \c138\ae08 \bd80\acfc \d56d\baa9.'-
));
INSERT INTO product_descriptions VALUES(2779-
,'KO'-
,UNISTR(-
'\cc45\c0c1 - OS/O/F'-
),UNISTR(-
'\d30c\c77c \c11c\b78d\c7a5\c774 \c788\b294 \c0ac\bb34\d615 '||-
'\d2b9\b300 \c624\d06c \cc45\c0c1. \c8fc\bb38 \c2dc \bc1d\ac70'||-
'\b098 \c9c4\d55c \c624\d06c \b610\b294 \c218\c81c\b85c \b9c8'||-
'\bb34\b9ac.'-
));
INSERT INTO product_descriptions VALUES(3337-
,'KO'-
,UNISTR(-
'\c774\b3d9 \c6f9 \c804\d654'-
),UNISTR(-
'\c6d4\bcc4 \c6f9 \c561\c138\c2a4 \c694\ae08\c774 \d3ec\d568'||-
'\b418\b294 \c774\b3d9 \c804\d654. \c2ac\b9bc\d615, \ac00\c8fd '||-
'\cf00\c774\c2a4 \bc0f \bca8\d2b8 \d074\b9bd \d3ec\d568.'-
));
INSERT INTO product_descriptions VALUES(2091-
,'KO'-
,UNISTR(-
'\ba54\baa8\c9c0 LW 8 1/2 x 11'-
),UNISTR(-
'\ba54\baa8\c9c0, \c120, \d770\c0c9, \d06c\ae30 8 1/2 x 11\c778'||-
'\ce58'-
));
INSERT INTO product_descriptions VALUES(2093-
,'KO'-
,UNISTR(-
'\d39c - 10/FP'-
),UNISTR(-
'\be68\b9ac \b9c8\b974\b294 \b0b4\c720\c131 \c601\ad6c \c789'||-
'\d06c \d39c. \bd80\b4dc\b7fd\ace0 \b04a\ae40 \c5c6\b294 \d544'||-
'\ae30\ac10. \c138\d544\c6a9. \b2e8\c0c9 \c0c1\c790(\ac80\c815, '||-
'\d30c\b791, \be68\ac15) \b610\b294 \c885\d569 \c0c1\c790(\ac80'||-
'\c815 6, \d30c\b791 3, \be68\ac15 1).'-
));
INSERT INTO product_descriptions VALUES(2144-
,'KO'-
,UNISTR(-
'\ba85\d568\cca9 \cee4\bc84'-
),UNISTR(-
'\b370\c2a4\d06c\d1b1 \c2a4\d0c0\c77c \ba85\d568 \af42\c774 '||-
'\ad50\ccb4 \cee4\bc84. \d68c\c0c9(\c6d0\b798 \c0c9\c0c1) \b610'||-
'\b294 \d22c\ba85 \d50c\b77c\c2a4\d2f1.'-
));
INSERT INTO product_descriptions VALUES(2336-
,'KO'-
,UNISTR(-
'\ba85\d568 \c0c1\c790 - 250'-
),UNISTR(-
'\ba85\d568 \c0c1\c790, 250\b9e4. \c8fc\bb38 \c2dc BC110-2, Rev. 3/'||-
'2000(\c778\c1c4 \c591\c2dd \b610\b294 \c628\b77c\c778)\c744 '||-
'\c0ac\c6a9\d558\c5ec \bcc4\d45c \d45c\c2dc\b41c \baa8\b4e0 '||-
'\d544\b4dc\c5d0 \ae30\c785\d558\c2ed\c2dc\c624.'-
));
INSERT INTO product_descriptions VALUES(2337-
,'KO'-
,UNISTR(-
'\ba85\d568 - 1000/2L'-
),UNISTR(-
'\ba85\d568 \c0c1\c790, 1000\b9e4, \c591\ba74 2\ac1c \ad6d\c5b4. '||-
'\c8fc\bb38 \c2dc BC111-2, Rev. 12/1999(\c778\c1c4 \c591\c2dd \b610'||-
'\b294 \c628\b77c\c778)\b97c \c0ac\c6a9\d558\c5ec \bcc4\d45c '||-
'\d45c\c2dc\b41c \d544\b4dc\c640 2\ba74 \c5b8\c5b4(1\ba74\c740 '||-
'\d56d\c0c1 \c601\c5b4) \d655\c778\b780\c744 \baa8\b450 \ae30'||-
'\c785\d558\c2ed\c2dc\c624.'-
));
INSERT INTO product_descriptions VALUES(2339-
,'KO'-
,UNISTR(-
'\c6a9\c9c0 - \d45c\c900 \d504\b9b0\d130'-
),UNISTR(-
'9kg. 8.5x11\c778\ce58 \d770\c0c9 \b808\c774\c800 \d504\b9b0\d130'||-
' \c6a9\c9c0(\c7ac\d65c\c6a9), 500\b9e4 \bb36\c74c 10\ac1c'-
));
INSERT INTO product_descriptions VALUES(2536-
,'KO'-
,UNISTR(-
'\ba85\d568 - 250/2L'-
),UNISTR(-
'\ba85\d568 \c0c1\c790, 250\b9e4, \c591\ba74 2\ac1c \ad6d\c5b4. '||-
'\c8fc\bb38 \c2dc BC111-2, Rev. 12/1999(\c778\c1c4 \c591\c2dd \b610'||-
'\b294 \c628\b77c\c778)\c744 \c0ac\c6a9\d558\c5ec \bcc4\d45c '||-
'\d45c\c2dc\b41c \d544\b4dc\c640 2\ba74 \c5b8\c5b4(1\ba74\c740 '||-
'\d56d\c0c1 \c601\c5b4) \d655\c778\b780\c744 \baa8\b450 \ae30'||-
'\c785\d558\c2ed\c2dc\c624.'-
));
INSERT INTO product_descriptions VALUES(2537-
,'KO'-
,UNISTR(-
'\ba85\d568 \c0c1\c790 - 1000'-
),UNISTR(-
'\ba85\d568 \c0c1\c790, 1000\b9e4. \c8fc\bb38 \c2dc BC110-3, Rev. 3'||-
'/2000(\c778\c1c4 \c591\c2dd \b610\b294 \c628\b77c\c778) \c591'||-
'\c2dd\c744 \c0ac\c6a9\d558\c5ec \bcc4\d45c \d45c\c2dc\b41c '||-
'\baa8\b4e0 \d544\b4dc\b97c \ae30\c785\d558\c2ed\c2dc\c624.'-
));
INSERT INTO product_descriptions VALUES(2783-
,'KO'-
,UNISTR(-
'\d074\b9bd - \c885\c774'-
),UNISTR(-
'\d45c\c900 \d488\c9c8\c758 \c885\c774 \d074\b9bd.100\ac1c \b4e4'||-
'\c774 10 \c0c1\c790. #1 \bcf4\d1b5/\d2b9\b300, \b9e4\b048/\bbf8'||-
'\b044\b7fc \bc29\c9c0'-
));
INSERT INTO product_descriptions VALUES(2808-
,'KO'-
,UNISTR(-
'\ba54\baa8\c9c0 LY 8 1/2 x 11'-
),UNISTR(-
'\ba54\baa8\c9c0, \c120, \b178\b791, \d06c\ae30 8 1/2 x 11\c778'||-
'\ce58'-
));
INSERT INTO product_descriptions VALUES(2810-
,'KO'-
,UNISTR(-
'\c789\d06c \d22c\ba85 \d39c'-
),UNISTR(-
'\b05d\c774 \bd80\b4dc\b7fd\ace0 \ac00\b294 \b864\b7ec \bcfc'||-
'\d39c. \c190\c7a1\c774 \bd80\bd84\c5d0 \d22c\ba85\d55c \ace0'||-
'\bb34\ac00 \c788\c5b4 \c789\d06c \acf5\ae09\c744 \bcfc \c218 '||-
'\c788\ace0 \d544\ae30\ac10 \c6b0\c218. \ac80\c815, \d30c\b791, '||-
'\be68\ac15, \b179\c0c9 \d558\b098\c529 4\d329'-
));
INSERT INTO product_descriptions VALUES(2870-
,'KO'-
,UNISTR(-
'\c5f0\d544 - Mech'-
),UNISTR(-
'\c778\ccb4 \acf5\d559\c801\c73c\b85c \b514\c790\c778\b418\c5b4'||-
' \d3b8\b9ac\d55c \c5f0\d544. \c9c0\c6b0\ac1c \bc0f \c2ec \ad50'||-
'\ccb4 \ac00\b2a5. 5mm(\c18c), 7mm(\c911) \bc0f 9mm(\b300) \d06c'||-
'\ae30\c758 \c2ec \c0ac\c6a9 \ac00\b2a5.'-
));
INSERT INTO product_descriptions VALUES(3051-
,'KO'-
,UNISTR(-
'\d39c - 10/MP'-
),UNISTR(-
'\be60\b974\ac8c \b9c8\b974\b294 \b0b4\c720\c131 \c601\ad6c '||-
'\c789\d06c \d39c. \bd80\b4dc\b7fd\ace0 \b04a\ae40 \c5c6\b294 '||-
'\d544\ae30\ac10. \c911\ac04 \ad75\ae30. \b2e8\c0c9 \c0c1\c790('||-
'\ac80\c815, \d30c\b791, \be68\ac15) \b610\b294 \c885\d569 \c0c1'||-
'\c790(\ac80\c815 6, \d30c\b791 3, \be68\ac15 1).'-
));
INSERT INTO product_descriptions VALUES(3150-
,'KO'-
,UNISTR(-
'\ba85\d568 \af42\c774- 25'-
),UNISTR(-
'\ba85\d568 \af42\c774. \d68c\c0ac \b85c\ace0\ac00 \c0c8\aca8'||-
'\c9c4 \b450\aebc\c6b4 \d50c\b77c\c2a4\d2f1 \ba85\d568 \af42'||-
'\c774. \ba85\d568 \c57d 25\b9e4 \c0ac\c6a9 \ac00\b2a5(\ba85'||-
'\d568 \b450\aed8\c5d0 \b530\b77c \b2e4\b984).'-
));
INSERT INTO product_descriptions VALUES(3208-
,'KO'-
,UNISTR(-
'\c5f0\d544 - \b098\bb34'-
),UNISTR(-
'\b098\bb34 \c5f0\d544 2\b2e4\c2a4. \c8fc\bb38 \c2dc 2H(\ac15'||-
'\b3c4 \b192\c74c), H(\ac15\b3c4 \c911\ac04), HB(\b2e8\b2e8\d55c '||-
'\ac80\c815), B(\bd80\b4dc\b7ec\c6b4 \ac80\c815) \c911 \c120'||-
'\d0dd.'-
));
INSERT INTO product_descriptions VALUES(3209-
,'KO'-
,UNISTR(-
'\c5f0\d544 \ae4e\ae30 - \c5f0\d544'-
),UNISTR(-
'\c804\ae30 \c5f0\d544 \ae4e\ae30. \c218\ba85\c774 \ae34 \d2bc'||-
'\d2bc\d55c \ac15\cca0 \cee4\d130. PencilSaver\ac00 \c9c0\b098'||-
'\ce58\ac8c \b0a0\ce74\b86d\ac8c \ae4e\c774\c9c0 \c54a\b3c4'||-
'\b85d \bc29\c9c0. \bbf8\b044\b7fc \bc29\c9c0 \ace0\bb34 \bc1c. '||-
'\c5f0\d544 \af42\c774 \b0b4\c7a5.'-
));
INSERT INTO product_descriptions VALUES(3224-
,'KO'-
,UNISTR(-
'\ba85\d568\cca9 - 250'-
),UNISTR(-
'\ba85\d568 \af42\c774, 250\b9e4. \d22c\ba85 \c8fc\ba38\b2c8'||-
'\c5d0 \ba85\d568\c744 \b123\c744 \c218 \c788\b294 \c18c\cc45'||-
'\c790 \c2a4\d0c0\c77c. \bb38\c790\c21c \d0ed(\c120\d0dd \c0ac'||-
'\d56d). \c8fc\bb38 \c2dc \cee4\bc84 \c0c9\c0c1(\c9c4\d55c \ac08'||-
'\c0c9, \bca0\c774\c9c0, \c9c4\d64d\c0c9, \ac80\c815 \bc0f \bc1d'||-
'\c740 \d68c\c0c9) \c120\d0dd.'-
));
INSERT INTO product_descriptions VALUES(3225-
,'KO'-
,UNISTR(-
'\ba85\d568\cca9 - 1000'-
),UNISTR(-
'\bb38\c790\c21c\c73c\b85c \ba85\d568\c744 \c815\b9ac\d560 '||-
'\c218 \c788\b294 \ba85\d568 \af42\c774. 1000\b9e4. \ac80\c815 '||-
'\bc14\d0d5\c5d0 \d68c\c0c9 \cee4\bc84\c758 \b370\c2a4\d06c'||-
'\d1b1 \c2a4\d0c0\c77c. \c11c\b78d \c548\c5d0 \c218\b0a9 \c2dc '||-
'\b69c\aed1 \c81c\ac70 \ac00\b2a5.'-
));
INSERT INTO product_descriptions VALUES(3511-
,'KO'-
,UNISTR(-
'\c6a9\c9c0 - HQ \d504\b9b0\d130'-
),UNISTR(-
'\d504\b9b0\d130 \c6a9\c9c0 \ac78\b9bc \c800\d56d \d14c\c2a4'||-
'\d2b8\b41c \ace0\ae09 \c789\d06c\c82f \bc0f \b808\c774\c800 '||-
'\d504\b9b0\d130 \c6a9\c9c0. \bcf4\ad00\c744 \c704\d55c \bb34'||-
'\c0b0\c131. \bb34\ac8c 10kg. \bc1d\ae30 92. \d06c\ae30: 8 1/2 x 11'||-
'. 500\b9e4 \bb36\c74c.'-
));
INSERT INTO product_descriptions VALUES(3515-
,'KO'-
,UNISTR(-
'\c2ec \ad50\ccb4'-
),UNISTR(-
'\c5f0\d544\c6a9 \ad50\ccb4 \c2ec. \d55c \d329\b2f9 25\ac1c '||-
'\c2ec \bc0f \ad50\ccb4 \c9c0\c6b0\ac1c. 5mm(\c18c), 7mm(\c911) '||-
'\bc0f 9mm(\b300) \d06c\ae30 \c911 \c120\d0dd \ac00\b2a5.'-
));
INSERT INTO product_descriptions VALUES(2986-
,'KO'-
,UNISTR(-
'\c124\ba85\c11c - Vision OS/2x +'-
),UNISTR(-
'Vision Operating System V 2.x \bc0f Vision Office Suite \c124\ba85'||-
'\c11c'-
));
INSERT INTO product_descriptions VALUES(3163-
,'KO'-
,UNISTR(-
'\c124\ba85\c11c - Vision Net6.3/US'-
),UNISTR(-
'Vision Networking V6.3 Reference Manual. \ace0\ae09 \c554\d638\d654 U'||-
'S \bc84\c804.'-
));
INSERT INTO product_descriptions VALUES(3165-
,'KO'-
,UNISTR(-
'\c124\ba85\c11c - Vision Tools2.0'-
),UNISTR(-
'Vision Business Tools Suite V2.0 Reference Manual. \c124\ce58, \ad6c'||-
'\c131 \bc0f \c0ac\c6a9\c790 \c124\ba85\c11c \d3ec\d568.'-
));
INSERT INTO product_descriptions VALUES(3167-
,'KO'-
,UNISTR(-
'\c124\ba85\c11c - Vision OS/2.x'-
),UNISTR(-
'Vision Operating System V2.0/2.1/2/3 Reference Manual. Vision \c2dc\c2a4'||-
'\d15c \ad00\b9ac\c5d0 \b300\d55c \c804\ccb4 \c124\ce58, \ad6c'||-
'\c131, \ad00\b9ac \bc0f \c870\c815 \c815\bcf4\b97c \d3ec\d568'||-
'\d569\b2c8\b2e4. \c774 \c124\ba85\c11c\b294 \bc84\c804 2.0 '||-
'\bc0f 2.1 \ac1c\bcc4 \c124\ba85\c11c\b97c \b300\c2e0\d569\b2c8'||-
'\b2e4.'-
));
INSERT INTO product_descriptions VALUES(3216-
,'KO'-
,UNISTR(-
'\c124\ba85\c11c - Vision Net6.3'-
),UNISTR(-
'Vision Networking V6.3 Reference Manual. \ae30\bcf8 \c554\d638\d654 U'||-
'S \c774\c678 \bc84\c804.'-
));
INSERT INTO product_descriptions VALUES(3220-
,'KO'-
,UNISTR(-
'\c124\ba85\c11c - Vision OS/1.2'-
),UNISTR(-
'Vision Operating System V1.2 Reference Manual. Vision \c2dc\c2a4\d15c '||-
'\ad00\b9ac\c5d0 \b300\d55c \c804\ccb4 \c124\ce58, \ad6c\c131, '||-
'\ad00\b9ac \bc0f \c870\c815 \c815\bcf4.'-
));
INSERT INTO product_descriptions VALUES(1729-
,'KO'-
,UNISTR(-
'\d654\d559 \c81c\d488 - RCP'-
),UNISTR(-
'\ccad\c18c\c6a9 \d654\d559 \c81c\d488 - 3500 \b864\b7ec \ccad'||-
'\c18c \d328\b4dc'-
));
INSERT INTO product_descriptions VALUES(1910-
,'KO'-
,UNISTR(-
'FG \c7ac\ace0 - H'-
),UNISTR(-
'\c720\b9ac \c12c\c720 \c7ac\ace0 - \ac15\b825, \b450\aed8 1'-
));
INSERT INTO product_descriptions VALUES(1912-
,'KO'-
,UNISTR(-
'SS \c7ac\ace0 - 3mm'-
),UNISTR(-
'\c2a4\d14c\c778\b9ac\c2a4 \c7ac\ace0 - 3mm. \d45c\c900 \c804'||-
'\c6d0 \acf5\ae09\ae30, \b9c8\b354\bcf4\b4dc \d640\b354 \bc0f '||-
'\d558\b4dc \b4dc\b77c\c774\be0c\c5d0 \b300\d574 \c0ac\c804 '||-
'\cc9c\acf5 \ac00\b2a5. \cc9c\acf5 \c6a9\c9c0 \c8fc\bb38 \c2dc '||-
'\d574\b2f9 \c591\c2dd\c744 \c0ac\c6a9\d558\c5ec \baa8\b378 '||-
'\bc88\d638, \c704\ce58 \bc0f \cc9c\acf5\b41c \c6a9\c9c0 \d06c'||-
'\ae30\b97c \c9c0\c815\d558\c2ed\c2dc\c624.'-
));
INSERT INTO product_descriptions VALUES(1940-
,'KO'-
,UNISTR(-
'ESD \d314\cc0c/\d074\b9bd'-
),UNISTR(-
'\cef4\d4e8\d130 \c100\c2dc \b610\b294 \ae30\d0c0 \c811\c9c0'||-
'\b97c \c27d\ac8c \c5f0\acb0\d558\ae30 \c704\d55c \b9de\bb3c'||-
'\b9bc \d074\b9bd\c774 \c788\b294 \c815\c804\ae30 \bc29\c9c0 '||-
'\d314\cc0c'-
));
INSERT INTO product_descriptions VALUES(2030-
,'KO'-
,UNISTR(-
'\b77c\d14d\c2a4 \c7a5\ac11'-
),UNISTR(-
'\c5b4\c148\be14\b7ec, \d654\d559 \cc98\b9ac\ae30, \c815\be44'||-
'\c6a9 \b77c\d14d\c2a4 \c7a5\ac11. \ac15\b825, \c190\ac00\b77d '||-
'\bd80\bd84\c5d0 \bbf8\b044\b7fc \bc29\c9c0 \cc98\b9ac, \c548'||-
'\c804\c6a9 \c8fc\d669\c0c9. \bc29\c218 \bc0f \cda9\aca9 \bc29'||-
'\c9c0(220V/2A), 110(V/5A). \cd5c\b300 5\bd84\ae4c\c9c0 \c0b0\c131 '||-
'\bc29\c9c0.'-
));
INSERT INTO product_descriptions VALUES(2326-
,'KO'-
,UNISTR(-
'\d50c\b77c\c2a4\d2f1 \c7ac\ace0 - Y'-
),UNISTR(-
'\d50c\b77c\c2a4\d2f1 \c7ac\ace0 - \b178\b791, \d45c\c900 \d488'||-
'\c9c8.'-
));
INSERT INTO product_descriptions VALUES(2330-
,'KO'-
,UNISTR(-
'\d50c\b77c\c2a4\d2f1 \c7ac\ace0 - R'-
),UNISTR(-
'\d50c\b77c\c2a4\d2f1 \c7ac\ace0 - \be68\ac15, \d45c\c900 \d488'||-
'\c9c8.'-
));
INSERT INTO product_descriptions VALUES(2334-
,'KO'-
,UNISTR(-
'\c218\c9c0'-
),UNISTR(-
'\bc94\c6a9 \d569\c131 \c218\c9c0.'-
));
INSERT INTO product_descriptions VALUES(2340-
,'KO'-
,UNISTR(-
'\d654\d559 \c81c\d488 - SW'-
),UNISTR(-
'\ccad\c18c\c6a9 \d654\d559 \c81c\d488 - 3500 \c815\c804\ae30 '||-
'\bc29\c9c0 \c218\ac74'-
));
INSERT INTO product_descriptions VALUES(2365-
,'KO'-
,UNISTR(-
'\d654\d559 \c81c\d488 - TCS'-
),UNISTR(-
'\ccad\c18c\c6a9 \d654\d559 \c81c\d488 - 2500 \c6b4\c1a1 \ccad'||-
'\c18c \c2dc\d2b8'-
));
INSERT INTO product_descriptions VALUES(2594-
,'KO'-
,UNISTR(-
'FG \c7ac\ace0 - L'-
),UNISTR(-
'\c720\b9ac \c12c\c720 \c7ac\ace0 - \b0b4\bd80 \c5f4 \cc28\d3d0'||-
'\b97c \c704\d55c \acbd\b7c9, \b450\aed8 1/4'-
));
INSERT INTO product_descriptions VALUES(2596-
,'KO'-
,UNISTR(-
'SS \c7ac\ace0 - 1mm'-
),UNISTR(-
'\c2a4\d14c\c778\b9ac\c2a4 \c7ac\ace0 - 3mm. \d45c\c900 \b9c8'||-
'\b354\bcf4\b4dc \bc0f \c804\c9c0 \d640\b354\c5d0 \b300\d574 '||-
'\c0ac\c804 \cc9c\acf5 \ac00\b2a5. \cc9c\acf5 \c6a9\c9c0 \c8fc'||-
'\bb38 \c2dc \d574\b2f9 \c591\c2dd\c744 \c0ac\c6a9\d558\c5ec '||-
'\baa8\b378 \bc88\d638, \c704\ce58 \bc0f \cc9c\acf5\b41c \c6a9'||-
'\c9c0 \d06c\ae30\b97c \c9c0\c815\d558\c2ed\c2dc\c624.'-
));
INSERT INTO product_descriptions VALUES(2631-
,'KO'-
,UNISTR(-
'ESD \d314\cc0c/QR'-
),UNISTR(-
'\c815\c804\ae30 \bc29\c9c0 \d314\cc0c: \d0c8\cc29\c774 \ac04'||-
'\d3b8\d55c \cee4\b125\d130\ac00 \c788\b294 \b450 \ac1c\c758 '||-
'\b9ac\b4dc. \d55c \cabd\c740 \b098\c0ac\b85c \cef4\d4e8\d130 '||-
'\c100\c2dc\c5d0 \d56d\c0c1 \c601\ad6c\c801\c73c\b85c \c5f0'||-
'\acb0\b418\ba70 \d55c \cabd\c740 \d314\cc0c\c5d0 \c5f0\acb0'||-
'\b429\b2c8\b2e4. \c601\ad6c \b9ac\b4dc\b294 \cd94\ac00\b85c '||-
'\c0ac\c6a9\d560 \c218 \c788\c2b5\b2c8\b2e4.'-
));
INSERT INTO product_descriptions VALUES(2721-
,'KO'-
,UNISTR(-
'PC \ac00\bc29 - L/S'-
),UNISTR(-
'\ac80\c815 \ac00\c8fd \cef4\d4e8\d130 \ac00\bc29 - \c124\ba85'||-
'\c11c, \cd94\ac00 \d558\b4dc\c6e8\c5b4 \bc0f \c791\c5c5 \c6a9'||-
'\c9c0\b97c \b123\c744 \c218 \c788\b294 \c8fc\ba38\b2c8\ac00 '||-
'\c788\b294 \b2e8\c77c \b7a9\d1b1\c6a9 \ac00\bc29. \bcf4\d638'||-
'\c6a9 \b048 \c870\c808 \ac00\b2a5, \c804\c6d0 \acf5\ae09\ae30 '||-
'\bc0f \cf00\c774\be14\c6a9 \c8fc\ba38\b2c8 \c81c\ac70 \ac00'||-
'\b2a5.'-
));
INSERT INTO product_descriptions VALUES(2722-
,'KO'-
,UNISTR(-
'PC \ac00\bc29 - L/D'-
),UNISTR(-
'\ac80\c815 \ac00\c8fd \cef4\d4e8\d130 \ac00\bc29 - \cd94\ac00 '||-
'\d558\b4dc\c6e8\c5b4 \b610\b294 \c124\ba85\c11c \bc0f \c791'||-
'\c5c5 \c6a9\c9c0\b97c \b123\c744 \c218 \c788\b294 \c8fc\ba38'||-
'\b2c8\ac00 \c788\b294 \b7a9\d1b1 \b450 \b300\c6a9 \ac00\bc29. '||-
'\bcf4\d638\c6a9 \b048 \c870\c808 \ac00\b2a5, \c804\c6d0 \acf5'||-
'\ae09\ae30 \bc0f \cf00\c774\be14\c6a9 \c8fc\ba38\b2c8 \c81c'||-
'\ac70 \ac00\b2a5. \b108\be44\ac00 \b113\c5b4 \c0ac\c6a9\c774 '||-
'\d3b8\b9ac\d55c \c5b4\ae68 \b048.'-
));
INSERT INTO product_descriptions VALUES(2725-
,'KO'-
,UNISTR(-
'\ae30\acc4\c6a9 \ae30\b984'-
),UNISTR(-
'CD-ROM \b4dc\b77c\c774\be0c \b3c4\c5b4 \bc0f \c2ac\b77c\c774'||-
'\b4dc\c6a9 \c724\d65c\c720. \ae30\b984 \c591 \c870\c808\c744 '||-
'\c704\d55c \c790\ac00 \ccad\c18c \c870\c815 \b178\c990.'-
));
INSERT INTO product_descriptions VALUES(2782-
,'KO'-
,UNISTR(-
'PC \ac00\bc29 - C/S'-
),UNISTR(-
'\ce94\bc84\c2a4 \cef4\d4e8\d130 \ac00\bc29 - \c124\ba85\c11c, '||-
'\cd94\ac00 \d558\b4dc\c6e8\c5b4 \bc0f \c791\c5c5 \c6a9\c9c0'||-
'\b97c \b123\c744 \c218 \c788\b294 \c8fc\ba38\b2c8\ac00 \c788'||-
'\b294 \b2e8\c77c \b7a9\d1b1\c6a9 \ac00\bc29. \bcf4\d638\c6a9 '||-
'\b048 \c870\c808 \ac00\b2a5, \c804\c6d0 \acf5\ae09\ae30 \bc0f '||-
'\cf00\c774\be14\c6a9 \c8fc\ba38\b2c8 \c81c\ac70 \ac00\b2a5. '||-
'\c774\b3d9 \c2dc \c27d\ac8c \c0ac\c6a9\d560 \c218 \c788\b294 '||-
'\c678\bd80 \c6d0\d130\ce58 \c8fc\ba38\b2c8.'-
));
INSERT INTO product_descriptions VALUES(3187-
,'KO'-
,UNISTR(-
'\d50c\b77c\c2a4\d2f1 \c7ac\ace0 - B/HD'-
),UNISTR(-
'\d50c\b77c\c2a4\d2f1 \c7ac\ace0 - \d30c\b791, \ace0\bc00\b3c4.'-
));
INSERT INTO product_descriptions VALUES(3189-
,'KO'-
,UNISTR(-
'\d50c\b77c\c2a4\d2f1 \c7ac\ace0 - G'-
),UNISTR(-
'\d50c\b77c\c2a4\d2f1 \c7ac\ace0 - \b179\c0c9, \d45c\c900 \bc00'||-
'\b3c4.'-
));
INSERT INTO product_descriptions VALUES(3191-
,'KO'-
,UNISTR(-
'\d50c\b77c\c2a4\d2f1 \c7ac\ace0 - O'-
),UNISTR(-
'\d50c\b77c\c2a4\d2f1 \c7ac\ace0 - \c8fc\d669, \d45c\c900 \bc00'||-
'\b3c4.'-
));
INSERT INTO product_descriptions VALUES(3193-
,'KO'-
,UNISTR(-
'\d50c\b77c\c2a4\d2f1 \c7ac\ace0 - W/HD'-
),UNISTR(-
'\d50c\b77c\c2a4\d2f1 \c7ac\ace0 - \d770\c0c9, \ace0\bc00\b3c4.'-
));
commit;
set define on
